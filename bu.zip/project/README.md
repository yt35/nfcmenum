# NFCmenüm - Geleceğin Menü Teknolojisi

NFCmenüm, QR kod ve NFC teknolojisini birleştiren modern dijital menü platformudur. Restoranlar için hem pratik hem de premium deneyim sunar.

## 🚀 Kurulum ve Deployment

### 1. Supabase Kurulumu

1. **Supabase Projesi Oluşturun**
   - [Supabase](https://supabase.com) hesabı açın
   - Yeni proje oluşturun
   - Database şifrenizi kaydedin

2. **Environment Değişkenlerini Ayarlayın**
   ```bash
   cp .env.example .env
   ```
   
   `.env` dosyasını düzenleyin:
   ```env
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   VITE_APP_NAME=NFCmenüm
   VITE_APP_URL=https://nfcmenum.com.tr
   VITE_ADMIN_EMAIL=admin@nfcmenum.com.tr
   ```

3. **Database Migration Çalıştırın**
   - Supabase Dashboard > SQL Editor'e gidin
   - `supabase/migrations/create_user_system.sql` dosyasının içeriğini kopyalayın
   - SQL Editor'de çalıştırın

### 2. Hosting Kurulumu

1. **Build Alın**
   ```bash
   npm install
   npm run build
   ```

2. **Hosting'e Yükleyin**
   - `dist` klasörünün tüm içeriğini hosting'inizin public_html klasörüne yükleyin
   - `.htaccess` dosyasının da yüklendiğinden emin olun

3. **Domain Ayarları**
   - DNS ayarlarınızı kontrol edin
   - SSL sertifikası aktif olduğundan emin olun

### 3. Kullanıcı Kayıt Sistemi

Artık kullanıcılar:
- ✅ Kayıt olabilir (`/register`)
- ✅ Giriş yapabilir (`/login`)
- ✅ Şifre sıfırlayabilir (`/reset-password`)
- ✅ Profil bilgilerini güncelleyebilir
- ✅ Restoran oluşturabilir
- ✅ Menü yönetimi yapabilir

### 4. Admin Paneli

Admin girişi için:
- **E-posta**: `admin@nfcmenum.com.tr`
- **Şifre**: `kjkszpJ9.`

## 📱 Özellikler

### 🎯 Temel Özellikler
- **Kullanıcı Kayıt Sistemi**: Güvenli kayıt ve giriş
- **QR Kod Menüleri**: Evrensel uyumluluk ile tüm cihazlarda çalışır
- **NFC Teknolojisi**: Tek dokunuşla menüye erişim
- **Mobil Optimizasyon**: Mükemmel mobil deneyim
- **Fiziksel Standlar**: QR ve NFC destekli özel tasarım masa standları
- **Detaylı Analytics**: Menü görüntüleme istatistikleri
- **Özel Tasarım**: Markanıza uygun renk, logo ve tema seçenekleri

### 👨‍💼 Admin Paneli
- **Kullanıcı Yönetimi**: Tüm kullanıcıları görüntüleme, düzenleme ve yönetme
- **Plan Yönetimi**: Fiyatlandırma planlarını oluşturma ve düzenleme
- **Stand Yönetimi**: Fiziksel standları yönetme
- **Analytics Dashboard**: Detaylı istatistikler ve raporlar

### 🔐 Güvenlik
- **Supabase Auth**: Güvenli kimlik doğrulama
- **Row Level Security (RLS)**: Veri güvenliği
- **Şifre Sıfırlama**: E-posta ile güvenli şifre sıfırlama
- **Admin Koruması**: Özel admin erişim kontrolü

## 🛠️ Teknoloji Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **Routing**: React Router DOM
- **Authentication**: Supabase Auth
- **Database**: Supabase (PostgreSQL)
- **Build Tool**: Vite
- **Deployment**: Static Hosting Ready

## 🗄️ Database Yapısı

### Tablolar
1. **profiles** - Kullanıcı profil bilgileri
2. **restaurants** - Restoran bilgileri
3. **menu_categories** - Menü kategorileri
4. **menu_items** - Menü ürünleri
5. **plans** - Abonelik planları

### Güvenlik
- Row Level Security (RLS) aktif
- Kullanıcılar sadece kendi verilerini görebilir
- Public menü görüntüleme için özel politikalar

## 📞 Destek

### İletişim
- **E-posta**: support@nfcmenum.com.tr
- **Website**: https://nfcmenum.com.tr

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır.

---

**NFCmenüm** - Restoranınızı dijital çağa taşıyın! 🚀