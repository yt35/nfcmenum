-- NFCmenüm Database Schema
-- Bu kodu Supabase SQL Editor'de çalıştırın

-- 1. Planlar tablosu (genel erişim)
CREATE TABLE IF NOT EXISTS plans (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  price integer NOT NULL DEFAULT 0,
  features text[] NOT NULL DEFAULT '{}',
  restaurant_limit integer DEFAULT 1,
  product_limit integer DEFAULT 10,
  nfc_enabled boolean DEFAULT false,
  analytics_enabled boolean DEFAULT false,
  custom_design boolean DEFAULT false,
  priority_support boolean DEFAULT false,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 2. Kullanıcı profilleri tablosu
CREATE TABLE IF NOT EXISTS profiles (
  id uuid REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  business_name text NOT NULL,
  phone text,
  plan_id uuid REFERENCES plans(id) DEFAULT NULL,
  subscription_status text DEFAULT 'free' CHECK (subscription_status IN ('free', 'active', 'cancelled', 'expired')),
  subscription_end_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 3. Restoranlar tablosu
CREATE TABLE IF NOT EXISTS restaurants (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid REFERENCES auth.users ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text,
  logo_url text,
  theme_color text DEFAULT '#ea580c',
  phone text,
  address text,
  website text,
  qr_code_url text,
  nfc_enabled boolean DEFAULT false,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 4. Menü kategorileri
CREATE TABLE IF NOT EXISTS menu_categories (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE NOT NULL,
  name text NOT NULL,
  description text,
  display_order integer DEFAULT 0,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 5. Menü ürünleri
CREATE TABLE IF NOT EXISTS menu_items (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  restaurant_id uuid REFERENCES restaurants(id) ON DELETE CASCADE NOT NULL,
  category_id uuid REFERENCES menu_categories(id) ON DELETE SET NULL,
  name text NOT NULL,
  description text,
  price decimal(10,2) NOT NULL DEFAULT 0,
  image_url text,
  preparation_time integer, -- dakika cinsinden
  available boolean DEFAULT true,
  featured boolean DEFAULT false,
  allergens text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 6. Varsayılan planları ekle
INSERT INTO plans (name, price, features, restaurant_limit, product_limit, nfc_enabled, analytics_enabled, custom_design, priority_support) VALUES
('Ücretsiz', 0, ARRAY['1 Restoran', 'QR Kod Menü', '10 Ürün Limiti', 'Temel Şablonlar', 'Email Destek'], 1, 10, false, false, false, false),
('Profesyonel', 299, ARRAY['3 Restoran', 'QR + NFC Menü', 'Sınırsız Ürün', 'Gelişmiş Analytics', 'Özel Tasarım', 'Öncelikli Destek', '2 Adet Ücretsiz Stand'], 3, -1, true, true, true, true),
('Kurumsal', 799, ARRAY['Sınırsız Restoran', 'Tüm Özellikler', 'API Erişimi', 'Özel Entegrasyonlar', 'Dedicated Hesap Yöneticisi', '5 Adet Ücretsiz Stand', 'Özel Eğitim'], -1, -1, true, true, true, true)
ON CONFLICT DO NOTHING;

-- 7. RLS Politikaları

-- Profiles tablosu
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Restaurants tablosu
ALTER TABLE restaurants ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can view own restaurants" ON restaurants;
CREATE POLICY "Users can view own restaurants" ON restaurants
  FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can insert own restaurants" ON restaurants;
CREATE POLICY "Users can insert own restaurants" ON restaurants
  FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can update own restaurants" ON restaurants;
CREATE POLICY "Users can update own restaurants" ON restaurants
  FOR UPDATE USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can delete own restaurants" ON restaurants;
CREATE POLICY "Users can delete own restaurants" ON restaurants
  FOR DELETE USING (auth.uid() = user_id);

-- Public access to restaurants for menu viewing
DROP POLICY IF EXISTS "Public can view active restaurants" ON restaurants;
CREATE POLICY "Public can view active restaurants" ON restaurants
  FOR SELECT USING (active = true);

-- Menu categories tablosu
ALTER TABLE menu_categories ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage own restaurant categories" ON menu_categories;
CREATE POLICY "Users can manage own restaurant categories" ON menu_categories
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM restaurants 
      WHERE restaurants.id = menu_categories.restaurant_id 
      AND restaurants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Public can view active categories" ON menu_categories;
CREATE POLICY "Public can view active categories" ON menu_categories
  FOR SELECT USING (
    active = true AND
    EXISTS (
      SELECT 1 FROM restaurants 
      WHERE restaurants.id = menu_categories.restaurant_id 
      AND restaurants.active = true
    )
  );

-- Menu items tablosu
ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Users can manage own restaurant menu items" ON menu_items;
CREATE POLICY "Users can manage own restaurant menu items" ON menu_items
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM restaurants 
      WHERE restaurants.id = menu_items.restaurant_id 
      AND restaurants.user_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "Public can view available menu items" ON menu_items;
CREATE POLICY "Public can view available menu items" ON menu_items
  FOR SELECT USING (
    available = true AND
    EXISTS (
      SELECT 1 FROM restaurants 
      WHERE restaurants.id = menu_items.restaurant_id 
      AND restaurants.active = true
    )
  );

-- Plans tablosu (herkes görebilir)
ALTER TABLE plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Plans are viewable by everyone" ON plans;
CREATE POLICY "Plans are viewable by everyone" ON plans
  FOR SELECT USING (active = true);

-- 8. Trigger fonksiyonları
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Updated_at triggerları
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_restaurants_updated_at ON restaurants;
CREATE TRIGGER update_restaurants_updated_at BEFORE UPDATE ON restaurants
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_menu_items_updated_at ON menu_items;
CREATE TRIGGER update_menu_items_updated_at BEFORE UPDATE ON menu_items
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 9. Kullanıcı kaydında otomatik profil oluşturma fonksiyonu
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
DECLARE
  free_plan_id uuid;
BEGIN
  -- Ücretsiz planın ID'sini al
  SELECT id INTO free_plan_id FROM plans WHERE name = 'Ücretsiz' LIMIT 1;
  
  INSERT INTO public.profiles (id, email, first_name, last_name, business_name, phone, plan_id)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'first_name', ''),
    COALESCE(new.raw_user_meta_data->>'last_name', ''),
    COALESCE(new.raw_user_meta_data->>'business_name', ''),
    COALESCE(new.raw_user_meta_data->>'phone', ''),
    free_plan_id
  );
  RETURN new;
END;
$$ language plpgsql security definer;

-- Trigger: Yeni kullanıcı kaydında profil oluştur
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();