/*
  # Fix Registration Database Error

  This migration addresses the "Database error saving new user" issue by:
  1. Ensuring the plans table has the required default plans
  2. Fixing the handle_new_user trigger function
  3. Adding proper error handling and logging
  4. Ensuring all required tables and policies are in place
*/

-- 1. First, ensure the plans table exists and has the correct structure
CREATE TABLE IF NOT EXISTS plans (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  price integer NOT NULL DEFAULT 0,
  features text[] NOT NULL DEFAULT '{}',
  restaurant_limit integer DEFAULT 1,
  product_limit integer DEFAULT 10,
  nfc_enabled boolean DEFAULT false,
  analytics_enabled boolean DEFAULT false,
  custom_design boolean DEFAULT false,
  priority_support boolean DEFAULT false,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- 2. Ensure profiles table exists with correct structure
CREATE TABLE IF NOT EXISTS profiles (
  id uuid REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  email text UNIQUE NOT NULL,
  first_name text NOT NULL,
  last_name text NOT NULL,
  business_name text NOT NULL,
  phone text,
  plan_id uuid REFERENCES plans(id) DEFAULT NULL,
  subscription_status text DEFAULT 'free' CHECK (subscription_status IN ('free', 'active', 'cancelled', 'expired')),
  subscription_end_date timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- 3. Clear existing plans and insert fresh default plans
DELETE FROM plans WHERE name IN ('Ücretsiz', 'Profesyonel', 'Kurumsal');

INSERT INTO plans (name, price, features, restaurant_limit, product_limit, nfc_enabled, analytics_enabled, custom_design, priority_support, active) VALUES
('Ücretsiz', 0, ARRAY['1 Restoran', 'QR Kod Menü', '10 Ürün Limiti', 'Temel Şablonlar', 'Email Destek'], 1, 10, false, false, false, false, true),
('Profesyonel', 299, ARRAY['3 Restoran', 'QR + NFC Menü', 'Sınırsız Ürün', 'Gelişmiş Analytics', 'Özel Tasarım', 'Öncelikli Destek', '2 Adet Ücretsiz Stand'], 3, -1, true, true, true, true, true),
('Kurumsal', 799, ARRAY['Sınırsız Restoran', 'Tüm Özellikler', 'API Erişimi', 'Özel Entegrasyonlar', 'Dedicated Hesap Yöneticisi', '5 Adet Ücretsiz Stand', 'Özel Eğitim'], -1, -1, true, true, true, true, true);

-- 4. Create improved handle_new_user function with better error handling
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
DECLARE
  free_plan_id uuid;
  user_email text;
  user_first_name text;
  user_last_name text;
  user_business_name text;
  user_phone text;
BEGIN
  -- Log the trigger execution
  RAISE LOG 'handle_new_user trigger started for user: %', NEW.id;
  
  -- Get the free plan ID
  SELECT id INTO free_plan_id 
  FROM plans 
  WHERE name = 'Ücretsiz' AND active = true 
  LIMIT 1;
  
  -- Check if free plan exists
  IF free_plan_id IS NULL THEN
    RAISE EXCEPTION 'Free plan not found. Cannot create user profile.';
  END IF;
  
  -- Extract user data safely
  user_email := COALESCE(NEW.email, '');
  user_first_name := COALESCE(NEW.raw_user_meta_data->>'first_name', 'Kullanıcı');
  user_last_name := COALESCE(NEW.raw_user_meta_data->>'last_name', '');
  user_business_name := COALESCE(NEW.raw_user_meta_data->>'business_name', 'İşletmem');
  user_phone := COALESCE(NEW.raw_user_meta_data->>'phone', '');
  
  -- Validate required fields
  IF user_email = '' THEN
    RAISE EXCEPTION 'User email is required';
  END IF;
  
  -- Insert profile with error handling
  BEGIN
    INSERT INTO public.profiles (
      id, 
      email, 
      first_name, 
      last_name, 
      business_name, 
      phone, 
      plan_id,
      subscription_status
    ) VALUES (
      NEW.id,
      user_email,
      user_first_name,
      user_last_name,
      user_business_name,
      user_phone,
      free_plan_id,
      'free'
    );
    
    RAISE LOG 'Profile created successfully for user: %', NEW.id;
    
  EXCEPTION WHEN OTHERS THEN
    RAISE EXCEPTION 'Failed to create user profile: %', SQLERRM;
  END;
  
  RETURN NEW;
END;
$$ language plpgsql security definer;

-- 5. Recreate the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 6. Enable RLS and create policies for plans table
ALTER TABLE plans ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Plans are viewable by everyone" ON plans;
CREATE POLICY "Plans are viewable by everyone" ON plans
  FOR SELECT USING (active = true);

-- 7. Enable RLS and create policies for profiles table
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable read access for all users" ON profiles;
CREATE POLICY "Enable read access for all users" ON profiles
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can view own profile" ON profiles;
CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
CREATE POLICY "Users can update own profile" ON profiles
  FOR UPDATE USING (auth.uid() = id);

DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
CREATE POLICY "Users can insert own profile" ON profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- 8. Create updated_at trigger function if it doesn't exist
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- 9. Add updated_at trigger to profiles
DROP TRIGGER IF EXISTS update_profiles_updated_at ON profiles;
CREATE TRIGGER update_profiles_updated_at 
  BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 10. Verify the setup
DO $$
DECLARE
  plan_count integer;
  free_plan_exists boolean;
BEGIN
  -- Check if plans exist
  SELECT COUNT(*) INTO plan_count FROM plans WHERE active = true;
  SELECT EXISTS(SELECT 1 FROM plans WHERE name = 'Ücretsiz' AND active = true) INTO free_plan_exists;
  
  RAISE LOG 'Setup verification: % active plans found', plan_count;
  RAISE LOG 'Free plan exists: %', free_plan_exists;
  
  IF plan_count < 3 THEN
    RAISE WARNING 'Expected 3 plans, found %', plan_count;
  END IF;
  
  IF NOT free_plan_exists THEN
    RAISE EXCEPTION 'Free plan (Ücretsiz) not found after setup';
  END IF;
  
  RAISE LOG 'Database setup completed successfully';
END $$;