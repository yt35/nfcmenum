# MySQL/MariaDB Kurulum Rehberi

## 1. Hosting Hazırlığı

### Gereksinimler
- **PHP 8.0+** (hosting'inizde aktif olmalı)
- **MySQL 5.7+** veya **MariaDB 10.3+**
- **Apache/Nginx** web sunucusu
- **SSL Sertifikası** (Let's Encrypt ücretsiz)

### Hosting Kontrol Paneli
1. **cPanel/DirectAdmin** giriş yapın
2. **MySQL Databases** bölümüne gidin
3. Yeni database oluşturun: `nfcmenum_db`
4. Database kullanıcısı oluşturun: `nfcmenum_user`
5. Güçlü şifre belirleyin ve kaydedin

## 2. Database Yapısı

### SQL Dosyası Oluşturma
Hosting'inizde `database.sql` dosyası oluşturun:

```sql
-- NFCmenüm Database Schema
CREATE DATABASE IF NOT EXISTS nfcmenum_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nfcmenum_db;

-- Kullanıcılar tablosu
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    business_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    plan ENUM('free', 'professional', 'enterprise') DEFAULT 'free',
    email_verified BOOLEAN DEFAULT FALSE,
    email_verification_token VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Şifre sıfırlama tokenları
CREATE TABLE password_reset_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_token (token),
    INDEX idx_expires (expires_at)
);

-- Restoranlar tablosu
CREATE TABLE restaurants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    logo_url VARCHAR(500),
    theme_color VARCHAR(7) DEFAULT '#ea580c',
    phone VARCHAR(20),
    address TEXT,
    website VARCHAR(255),
    qr_code_url VARCHAR(500),
    nfc_enabled BOOLEAN DEFAULT FALSE,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Menü kategorileri
CREATE TABLE menu_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    display_order INT DEFAULT 0,
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE
);

-- Menü ürünleri
CREATE TABLE menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT NOT NULL,
    category_id INT,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    image_url VARCHAR(500),
    preparation_time INT, -- dakika
    available BOOLEAN DEFAULT TRUE,
    featured BOOLEAN DEFAULT FALSE,
    allergens JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES menu_categories(id) ON DELETE SET NULL
);

-- Oturumlar (session management)
CREATE TABLE user_sessions (
    id VARCHAR(255) PRIMARY KEY,
    user_id INT NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_expires (expires_at),
    INDEX idx_user (user_id)
);

-- Analytics tablosu
CREATE TABLE menu_views (
    id INT AUTO_INCREMENT PRIMARY KEY,
    restaurant_id INT NOT NULL,
    menu_item_id INT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (restaurant_id) REFERENCES restaurants(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_item_id) REFERENCES menu_items(id) ON DELETE SET NULL,
    INDEX idx_restaurant (restaurant_id),
    INDEX idx_viewed_at (viewed_at)
);

-- Admin kullanıcı oluştur
INSERT INTO users (email, password_hash, first_name, last_name, business_name, plan, email_verified) 
VALUES ('admin@nfcmenum.com.tr', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'User', 'NFCmenüm Admin', 'enterprise', TRUE);
```

### Database'i İçe Aktarma
1. **phpMyAdmin** açın
2. `nfcmenum_db` database'ini seçin
3. **Import** sekmesine gidin
4. `database.sql` dosyasını yükleyin
5. **Go** butonuna tıklayın

## 3. PHP Backend API

### Klasör Yapısı
```
public_html/
├── api/
│   ├── config/
│   │   ├── database.php
│   │   └── config.php
│   ├── auth/
│   │   ├── login.php
│   │   ├── register.php
│   │   ├── logout.php
│   │   └── reset-password.php
│   ├── restaurants/
│   │   ├── list.php
│   │   ├── create.php
│   │   ├── update.php
│   │   └── delete.php
│   ├── menu/
│   │   ├── categories.php
│   │   ├── items.php
│   │   └── public.php
│   └── utils/
│       ├── email.php
│       └── helpers.php
├── dist/ (React build dosyaları)
└── .htaccess
```

### Database Bağlantısı
`api/config/database.php`:

```php
<?php
class Database {
    private $host = 'localhost'; // Hosting'inizin DB host'u
    private $db_name = 'nfcmenum_db';
    private $username = 'nfcmenum_user';
    private $password = 'your_strong_password'; // Güçlü şifreniz
    private $conn;

    public function getConnection() {
        $this->conn = null;
        
        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name . ";charset=utf8mb4",
                $this->username,
                $this->password,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch(PDOException $e) {
            error_log("Connection error: " . $e->getMessage());
            die("Database connection failed");
        }
        
        return $this->conn;
    }
}
?>
```

### Genel Konfigürasyon
`api/config/config.php`:

```php
<?php
// Site ayarları
define('SITE_URL', 'https://nfcmenum.com.tr');
define('API_URL', SITE_URL . '/api');

// E-posta ayarları
define('SMTP_HOST', 'mail.nfcmenum.com.tr'); // Hosting SMTP
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'noreply@nfcmenum.com.tr');
define('SMTP_PASSWORD', 'your_email_password');
define('FROM_EMAIL', 'noreply@nfcmenum.com.tr');
define('FROM_NAME', 'NFCmenüm');

// JWT ayarları
define('JWT_SECRET', 'your_super_secret_jwt_key_here_make_it_long_and_random');
define('JWT_EXPIRE', 86400); // 24 saat

// Güvenlik
define('PASSWORD_MIN_LENGTH', 6);
define('SESSION_LIFETIME', 86400); // 24 saat

// CORS ayarları
header('Access-Control-Allow-Origin: ' . SITE_URL);
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=UTF-8');

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}
?>
```

## 4. Kimlik Doğrulama Sistemi

### Kayıt Olma
`api/auth/register.php`:

```php
<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

// Validation
$required = ['email', 'password', 'firstName', 'lastName', 'businessName'];
foreach ($required as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['error' => ucfirst($field) . ' is required']);
        exit();
    }
}

$email = filter_var($input['email'], FILTER_VALIDATE_EMAIL);
if (!$email) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email format']);
    exit();
}

if (strlen($input['password']) < PASSWORD_MIN_LENGTH) {
    http_response_code(400);
    echo json_encode(['error' => 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // E-posta kontrolü
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['error' => 'Email already exists']);
        exit();
    }
    
    // Kullanıcı oluştur
    $passwordHash = password_hash($input['password'], PASSWORD_DEFAULT);
    $verificationToken = bin2hex(random_bytes(32));
    
    $stmt = $db->prepare("
        INSERT INTO users (email, password_hash, first_name, last_name, business_name, phone, email_verification_token) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $email,
        $passwordHash,
        $input['firstName'],
        $input['lastName'],
        $input['businessName'],
        $input['phone'] ?? null,
        $verificationToken
    ]);
    
    $userId = $db->lastInsertId();
    
    // E-posta doğrulama gönder (opsiyonel)
    // sendVerificationEmail($email, $verificationToken);
    
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful',
        'userId' => $userId
    ]);
    
} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Registration failed']);
}
?>
```

### Giriş Yapma
`api/auth/login.php`:

```php
<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (empty($input['email']) || empty($input['password'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Email and password are required']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $stmt = $db->prepare("SELECT id, email, password_hash, first_name, last_name, business_name, plan FROM users WHERE email = ?");
    $stmt->execute([$input['email']]);
    $user = $stmt->fetch();
    
    if (!$user || !password_verify($input['password'], $user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Invalid credentials']);
        exit();
    }
    
    // Session oluştur
    $sessionId = bin2hex(random_bytes(32));
    $expiresAt = date('Y-m-d H:i:s', time() + SESSION_LIFETIME);
    
    $stmt = $db->prepare("
        INSERT INTO user_sessions (id, user_id, ip_address, user_agent, expires_at) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $sessionId,
        $user['id'],
        $_SERVER['REMOTE_ADDR'] ?? null,
        $_SERVER['HTTP_USER_AGENT'] ?? null,
        $expiresAt
    ]);
    
    // Cookie set et
    setcookie('session_id', $sessionId, time() + SESSION_LIFETIME, '/', '', true, true);
    
    echo json_encode([
        'success' => true,
        'user' => [
            'id' => $user['id'],
            'email' => $user['email'],
            'firstName' => $user['first_name'],
            'lastName' => $user['last_name'],
            'businessName' => $user['business_name'],
            'plan' => $user['plan']
        ],
        'sessionId' => $sessionId
    ]);
    
} catch (Exception $e) {
    error_log("Login error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Login failed']);
}
?>
```

## 5. Şifre Sıfırlama Sistemi

### Şifre Sıfırlama Talebi
`api/auth/reset-password.php`:

```php
<?php
require_once '../config/database.php';
require_once '../config/config.php';
require_once '../utils/email.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (empty($input['email'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Email is required']);
    exit();
}

$email = filter_var($input['email'], FILTER_VALIDATE_EMAIL);
if (!$email) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid email format']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Kullanıcı kontrolü
    $stmt = $db->prepare("SELECT id, first_name FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if (!$user) {
        // Güvenlik için her zaman başarılı mesaj döndür
        echo json_encode(['success' => true, 'message' => 'Reset link sent if email exists']);
        exit();
    }
    
    // Eski tokenları sil
    $stmt = $db->prepare("DELETE FROM password_reset_tokens WHERE user_id = ? OR expires_at < NOW()");
    $stmt->execute([$user['id']]);
    
    // Yeni token oluştur
    $token = bin2hex(random_bytes(32));
    $expiresAt = date('Y-m-d H:i:s', time() + 3600); // 1 saat
    
    $stmt = $db->prepare("INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$user['id'], $token, $expiresAt]);
    
    // E-posta gönder
    $resetLink = SITE_URL . "/reset-password?token=" . $token;
    $subject = "NFCmenüm - Şifre Sıfırlama";
    $message = "
        Merhaba {$user['first_name']},
        
        Şifre sıfırlama talebiniz alındı. Aşağıdaki bağlantıya tıklayarak yeni şifrenizi belirleyebilirsiniz:
        
        {$resetLink}
        
        Bu bağlantı 1 saat geçerlidir.
        
        Eğer bu talebi siz yapmadıysanız, bu e-postayı görmezden gelebilirsiniz.
        
        NFCmenüm Ekibi
    ";
    
    sendEmail($email, $subject, $message);
    
    echo json_encode(['success' => true, 'message' => 'Reset link sent if email exists']);
    
} catch (Exception $e) {
    error_log("Password reset error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Reset request failed']);
}
?>
```

### E-posta Gönderme Sistemi
`api/utils/email.php`:

```php
<?php
function sendEmail($to, $subject, $message) {
    $headers = [
        'From: ' . FROM_NAME . ' <' . FROM_EMAIL . '>',
        'Reply-To: ' . FROM_EMAIL,
        'Content-Type: text/plain; charset=UTF-8',
        'X-Mailer: PHP/' . phpversion()
    ];
    
    return mail($to, $subject, $message, implode("\r\n", $headers));
}

// SMTP ile gönderim için (PHPMailer kullanarak)
function sendEmailSMTP($to, $subject, $message) {
    // PHPMailer kütüphanesi gerekli
    // composer require phpmailer/phpmailer
    
    require_once '../vendor/autoload.php';
    
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = SMTP_HOST;
        $mail->SMTPAuth = true;
        $mail->Username = SMTP_USERNAME;
        $mail->Password = SMTP_PASSWORD;
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = SMTP_PORT;
        $mail->CharSet = 'UTF-8';
        
        $mail->setFrom(FROM_EMAIL, FROM_NAME);
        $mail->addAddress($to);
        
        $mail->Subject = $subject;
        $mail->Body = $message;
        
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Email error: " . $mail->ErrorInfo);
        return false;
    }
}
?>
```

## 6. Frontend Entegrasyonu

### API Service
`src/lib/api.ts`:

```typescript
const API_BASE = '/api';

export class ApiService {
  private async request(endpoint: string, options: RequestInit = {}) {
    const url = `${API_BASE}${endpoint}`;
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      credentials: 'include', // Cookie'ler için
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Request failed');
    }

    return response.json();
  }

  // Auth methods
  async login(email: string, password: string) {
    return this.request('/auth/login.php', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  }

  async register(userData: any) {
    return this.request('/auth/register.php', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async resetPassword(email: string) {
    return this.request('/auth/reset-password.php', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  }

  // Restaurant methods
  async getRestaurants() {
    return this.request('/restaurants/list.php');
  }

  async createRestaurant(data: any) {
    return this.request('/restaurants/create.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }
}

export const api = new ApiService();
```

## 7. Deployment

### Build ve Upload
```bash
# React build
npm run build

# Dosyaları hosting'e yükle
# dist/ klasörünün içeriğini public_html/ içine
# api/ klasörünü public_html/api/ içine
```

### .htaccess Ayarları
```apache
# React Router için
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteCond %{REQUEST_URI} !^/api/
RewriteRule . /index.html [L]

# API için
RewriteRule ^api/(.*)$ api/$1 [L]

# Güvenlik
<Files "*.php">
    Order Allow,Deny
    Allow from all
</Files>

<Files "config.php">
    Order Allow,Deny
    Deny from all
</Files>
```

## 8. Güvenlik Önlemleri

### SQL Injection Koruması
- ✅ PDO Prepared Statements kullanıldı
- ✅ Input validation yapıldı
- ✅ Parameterized queries kullanıldı

### XSS Koruması
- ✅ Input sanitization
- ✅ Output encoding
- ✅ Content-Type headers

### CSRF Koruması
- ✅ SameSite cookies
- ✅ Origin kontrolü
- ✅ CSRF token sistemi

### Şifre Güvenliği
- ✅ Password hashing (bcrypt)
- ✅ Minimum şifre uzunluğu
- ✅ Rate limiting

Bu sistem tamamen kendi hosting'inizde çalışır ve hiçbir dış servise bağımlı değildir!