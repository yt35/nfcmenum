<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

// Validation
$required = ['email', 'password', 'firstName', 'lastName', 'businessName'];
foreach ($required as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => ucfirst($field) . ' is required']);
        exit();
    }
}

$email = filter_var($input['email'], FILTER_VALIDATE_EMAIL);
if (!$email) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid email format']);
    exit();
}

if (strlen($input['password']) < PASSWORD_MIN_LENGTH) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Password must be at least ' . PASSWORD_MIN_LENGTH . ' characters']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // E-posta kontrolü
    $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->fetch()) {
        http_response_code(409);
        echo json_encode(['success' => false, 'error' => 'Email already exists']);
        exit();
    }
    
    // Ücretsiz plan ID'sini al
    $stmt = $db->prepare("SELECT id FROM plans WHERE name = 'Ücretsiz' LIMIT 1");
    $stmt->execute();
    $freePlan = $stmt->fetch();
    
    // Kullanıcı oluştur
    $passwordHash = password_hash($input['password'], PASSWORD_DEFAULT);
    $userId = bin2hex(random_bytes(16));
    
    $stmt = $db->prepare("
        INSERT INTO users (id, email, password_hash, first_name, last_name, business_name, phone, plan_id, email_verified) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, TRUE)
    ");
    
    $stmt->execute([
        $userId,
        $email,
        $passwordHash,
        $input['firstName'],
        $input['lastName'],
        $input['businessName'],
        $input['phone'] ?? null,
        $freePlan['id'] ?? null
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Registration successful',
        'data' => ['userId' => $userId]
    ]);
    
} catch (Exception $e) {
    error_log("Registration error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Registration failed: ' . $e->getMessage()]);
}
?>