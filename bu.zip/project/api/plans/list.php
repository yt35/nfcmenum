<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $stmt = $db->prepare("SELECT * FROM plans WHERE active = TRUE ORDER BY price ASC");
    $stmt->execute();
    $plans = $stmt->fetchAll();
    
    // JSON features'ı decode et
    foreach ($plans as &$plan) {
        $plan['features'] = json_decode($plan['features'], true);
    }
    
    echo json_encode([
        'success' => true,
        'data' => $plans
    ]);
    
} catch (Exception $e) {
    error_log("Plans list error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to fetch plans']);
}
?>