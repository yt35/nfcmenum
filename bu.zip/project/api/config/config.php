<?php
// Site ayarları
define('SITE_URL', 'https://nfcmenum.com.tr');
define('API_URL', SITE_URL . '/api');

// E-posta ayarları (Senkronet SMTP)
define('SMTP_HOST', 'mail.nfcmenum.com.tr');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'noreply@nfcmenum.com.tr');
define('SMTP_PASSWORD', 'your_email_password');
define('FROM_EMAIL', 'noreply@nfcmenum.com.tr');
define('FROM_NAME', 'NFCmenüm');

// JWT ayarları
define('JWT_SECRET', 'nfcmenum_super_secret_jwt_key_2024_very_long_and_secure');
define('JWT_EXPIRE', 86400); // 24 saat

// PayTR ayarları (Test modunda)
define('PAYTR_MERCHANT_ID', 'your_merchant_id');
define('PAYTR_MERCHANT_KEY', 'your_merchant_key');
define('PAYTR_MERCHANT_SALT', 'your_merchant_salt');

// Güvenlik
define('PASSWORD_MIN_LENGTH', 6);
define('SESSION_LIFETIME', 86400); // 24 saat

// CORS ayarları
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

// OPTIONS request için
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Error reporting (production'da kapatın)
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>