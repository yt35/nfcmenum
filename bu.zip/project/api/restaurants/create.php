<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

// Session kontrolü (basit versiyon)
$sessionId = $_COOKIE['session_id'] ?? null;
if (!$sessionId) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (empty($input['name'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Restaurant name is required']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Session'dan user ID al
    $stmt = $db->prepare("SELECT user_id FROM user_sessions WHERE id = ? AND expires_at > NOW()");
    $stmt->execute([$sessionId]);
    $session = $stmt->fetch();
    
    if (!$session) {
        http_response_code(401);
        echo json_encode(['success' => false, 'error' => 'Invalid session']);
        exit();
    }
    
    // Restoran oluştur
    $restaurantId = bin2hex(random_bytes(16));
    
    $stmt = $db->prepare("
        INSERT INTO restaurants (id, user_id, name, description, phone, address, website, theme_color) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $restaurantId,
        $session['user_id'],
        $input['name'],
        $input['description'] ?? null,
        $input['phone'] ?? null,
        $input['address'] ?? null,
        $input['website'] ?? null,
        $input['theme_color'] ?? '#ea580c'
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Restaurant created successfully',
        'data' => ['restaurant_id' => $restaurantId]
    ]);
    
} catch (Exception $e) {
    error_log("Restaurant creation error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Restaurant creation failed']);
}
?>