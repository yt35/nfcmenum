<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

// Validation
$required = ['name', 'email', 'subject', 'message'];
foreach ($required as $field) {
    if (empty($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => ucfirst($field) . ' is required']);
        exit();
    }
}

$email = filter_var($input['email'], FILTER_VALIDATE_EMAIL);
if (!$email) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid email format']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // İletişim mesajını kaydet
    $messageId = bin2hex(random_bytes(16));
    
    $stmt = $db->prepare("
        INSERT INTO contact_messages (id, name, email, phone, subject, message) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $messageId,
        $input['name'],
        $email,
        $input['phone'] ?? null,
        $input['subject'],
        $input['message']
    ]);
    
    // E-posta gönder (opsiyonel)
    // mail() fonksiyonu ile e-posta gönderebilirsiniz
    
    echo json_encode([
        'success' => true,
        'message' => 'Message sent successfully',
        'data' => ['message_id' => $messageId]
    ]);
    
} catch (Exception $e) {
    error_log("Contact message error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Message sending failed']);
}
?>