<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

// Validation
$required = ['restaurant_id', 'table_number', 'request_type'];
foreach ($required as $field) {
    if (!isset($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => ucfirst($field) . ' is required']);
        exit();
    }
}

$validTypes = ['service', 'bill', 'help'];
if (!in_array($input['request_type'], $validTypes)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid request type']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    // Garson çağrısı oluştur
    $callId = bin2hex(random_bytes(16));
    
    $stmt = $db->prepare("
        INSERT INTO waiter_calls (id, restaurant_id, table_number, request_type, message) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $callId,
        $input['restaurant_id'],
        $input['table_number'],
        $input['request_type'],
        $input['message'] ?? null
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Waiter call created successfully',
        'data' => ['call_id' => $callId]
    ]);
    
} catch (Exception $e) {
    error_log("Waiter call error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Waiter call failed']);
}
?>