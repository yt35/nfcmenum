<?php
require_once '../config/database.php';
require_once '../config/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

// Validation
$required = ['restaurant_id', 'table_number', 'items'];
foreach ($required as $field) {
    if (!isset($input[$field])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => ucfirst($field) . ' is required']);
        exit();
    }
}

if (empty($input['items']) || !is_array($input['items'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Items array cannot be empty']);
    exit();
}

try {
    $database = new Database();
    $db = $database->getConnection();
    
    $db->beginTransaction();
    
    // Sipariş oluştur
    $orderId = bin2hex(random_bytes(16));
    $totalAmount = 0;
    
    $stmt = $db->prepare("
        INSERT INTO orders (id, restaurant_id, table_number, customer_name, customer_phone, notes, total_amount) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $orderId,
        $input['restaurant_id'],
        $input['table_number'],
        $input['customer_name'] ?? null,
        $input['customer_phone'] ?? null,
        $input['notes'] ?? null,
        0 // Geçici, hesaplanacak
    ]);
    
    // Sipariş ürünlerini ekle
    foreach ($input['items'] as $item) {
        // Ürün fiyatını al
        $stmt = $db->prepare("SELECT price FROM menu_items WHERE id = ?");
        $stmt->execute([$item['menu_item_id']]);
        $menuItem = $stmt->fetch();
        
        if (!$menuItem) {
            throw new Exception('Menu item not found: ' . $item['menu_item_id']);
        }
        
        $unitPrice = $menuItem['price'];
        $quantity = $item['quantity'];
        $itemTotal = $unitPrice * $quantity;
        $totalAmount += $itemTotal;
        
        $stmt = $db->prepare("
            INSERT INTO order_items (id, order_id, menu_item_id, quantity, unit_price, total_price, notes) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            bin2hex(random_bytes(16)),
            $orderId,
            $item['menu_item_id'],
            $quantity,
            $unitPrice,
            $itemTotal,
            $item['notes'] ?? null
        ]);
    }
    
    // Toplam tutarı güncelle
    $stmt = $db->prepare("UPDATE orders SET total_amount = ? WHERE id = ?");
    $stmt->execute([$totalAmount, $orderId]);
    
    $db->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Order created successfully',
        'data' => [
            'order_id' => $orderId,
            'total_amount' => $totalAmount
        ]
    ]);
    
} catch (Exception $e) {
    $db->rollback();
    error_log("Order creation error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Order creation failed']);
}
?>