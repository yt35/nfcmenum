const API_BASE = import.meta.env.VITE_API_URL || '/api';

interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export class ApiService {
  private async request<T = any>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${API_BASE}${endpoint}`;
    
    const response = await fetch(url, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      credentials: 'include',
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || `HTTP ${response.status}: ${response.statusText}`);
    }

    return data;
  }

  // Auth methods
  async login(email: string, password: string) {
    return this.request<ApiResponse>('/auth/login.php', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  }

  async register(userData: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    businessName: string;
    phone?: string;
  }) {
    return this.request<ApiResponse>('/auth/register.php', {
      method: 'POST',
      body: JSON.stringify(userData),
    });
  }

  async logout() {
    return this.request<ApiResponse>('/auth/logout.php', {
      method: 'POST',
    });
  }

  async resetPassword(email: string) {
    return this.request<ApiResponse>('/auth/reset-password.php', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  }

  // User profile methods
  async getProfile() {
    return this.request<ApiResponse>('/user/profile.php');
  }

  async updateProfile(updates: any) {
    return this.request<ApiResponse>('/user/profile.php', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  // Restaurant methods
  async getRestaurants() {
    return this.request<ApiResponse>('/restaurants/list.php');
  }

  async getRestaurant(id: string) {
    return this.request<ApiResponse>(`/restaurants/get.php?id=${id}`);
  }

  async createRestaurant(data: {
    name: string;
    description?: string;
    phone?: string;
    address?: string;
    website?: string;
    theme_color?: string;
  }) {
    return this.request<ApiResponse>('/restaurants/create.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateRestaurant(id: string, data: any) {
    return this.request<ApiResponse>('/restaurants/update.php', {
      method: 'PUT',
      body: JSON.stringify({ id, ...data }),
    });
  }

  async deleteRestaurant(id: string) {
    return this.request<ApiResponse>('/restaurants/delete.php', {
      method: 'DELETE',
      body: JSON.stringify({ id }),
    });
  }

  // Menu methods
  async getMenuCategories(restaurantId: string) {
    return this.request<ApiResponse>(`/menu/categories.php?restaurant_id=${restaurantId}`);
  }

  async createMenuCategory(data: {
    restaurant_id: string;
    name: string;
    description?: string;
    display_order?: number;
  }) {
    return this.request<ApiResponse>('/menu/create-category.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateMenuCategory(id: string, data: any) {
    return this.request<ApiResponse>('/menu/update-category.php', {
      method: 'PUT',
      body: JSON.stringify({ id, ...data }),
    });
  }

  async deleteMenuCategory(id: string) {
    return this.request<ApiResponse>('/menu/delete-category.php', {
      method: 'DELETE',
      body: JSON.stringify({ id }),
    });
  }

  async getMenuItems(restaurantId: string) {
    return this.request<ApiResponse>(`/menu/items.php?restaurant_id=${restaurantId}`);
  }

  async getPublicMenu(restaurantId: string) {
    return this.request<ApiResponse>(`/menu/public.php?restaurant_id=${restaurantId}`);
  }

  async createMenuItem(data: {
    restaurant_id: string;
    category_id?: string;
    name: string;
    description?: string;
    price: number;
    image_url?: string;
    preparation_time?: number;
    available?: boolean;
    featured?: boolean;
    allergens?: string[];
  }) {
    return this.request<ApiResponse>('/menu/create-item.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateMenuItem(id: string, data: any) {
    return this.request<ApiResponse>('/menu/update-item.php', {
      method: 'PUT',
      body: JSON.stringify({ id, ...data }),
    });
  }

  async deleteMenuItem(id: string) {
    return this.request<ApiResponse>('/menu/delete-item.php', {
      method: 'DELETE',
      body: JSON.stringify({ id }),
    });
  }

  // Order methods
  async createOrder(data: {
    restaurant_id: string;
    table_number: number;
    items: Array<{
      menu_item_id: string;
      quantity: number;
      notes?: string;
    }>;
    customer_name?: string;
    customer_phone?: string;
  }) {
    return this.request<ApiResponse>('/orders/create.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getOrders(restaurantId: string, status?: string) {
    const params = new URLSearchParams();
    params.append('restaurant_id', restaurantId);
    if (status) params.append('status', status);
    
    return this.request<ApiResponse>(`/orders/list.php?${params.toString()}`);
  }

  async updateOrderStatus(orderId: string, status: string) {
    return this.request<ApiResponse>('/orders/update-status.php', {
      method: 'PUT',
      body: JSON.stringify({ id: orderId, status }),
    });
  }

  // Waiter call methods
  async callWaiter(data: {
    restaurant_id: string;
    table_number: number;
    request_type: 'service' | 'bill' | 'help';
    message?: string;
  }) {
    return this.request<ApiResponse>('/waiter/call.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getWaiterCalls(restaurantId: string) {
    return this.request<ApiResponse>(`/waiter/calls.php?restaurant_id=${restaurantId}`);
  }

  async respondToWaiterCall(callId: string, response: string) {
    return this.request<ApiResponse>('/waiter/respond.php', {
      method: 'PUT',
      body: JSON.stringify({ id: callId, response }),
    });
  }

  // Analytics methods
  async getAnalytics(restaurantId: string, period: string = '30d') {
    return this.request<ApiResponse>(`/analytics/stats.php?restaurant_id=${restaurantId}&period=${period}`);
  }

  async trackMenuView(restaurantId: string, itemId?: string) {
    return this.request<ApiResponse>('/analytics/track.php', {
      method: 'POST',
      body: JSON.stringify({ 
        restaurant_id: restaurantId, 
        menu_item_id: itemId 
      }),
    });
  }

  // Payment methods
  async createPayment(data: {
    plan_id: string;
    user_email: string;
    amount: number;
    currency: string;
  }) {
    return this.request<ApiResponse>('/payment/create.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async verifyPayment(paymentId: string) {
    return this.request<ApiResponse>(`/payment/verify.php?payment_id=${paymentId}`);
  }

  // Contact form
  async sendContactMessage(data: {
    name: string;
    email: string;
    phone?: string;
    subject: string;
    message: string;
  }) {
    return this.request<ApiResponse>('/contact/send.php', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Plans
  async getPlans() {
    return this.request<ApiResponse>('/plans/list.php');
  }

  // QR Code generation
  async generateQRCode(restaurantId: string) {
    return this.request<ApiResponse>('/qr/generate.php', {
      method: 'POST',
      body: JSON.stringify({ restaurant_id: restaurantId }),
    });
  }
}

export const api = new ApiService();