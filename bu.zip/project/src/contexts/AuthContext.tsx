import React, { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../lib/api';

interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  businessName: string;
  phone?: string;
  plan?: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signUp: (email: string, password: string, userData: any) => Promise<any>;
  signIn: (email: string, password: string) => Promise<any>;
  signOut: () => Promise<void>;
  updateProfile: (updates: any) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const response = await api.getProfile();
      if (response.success) {
        setUser(response.data);
      }
    } catch (error) {
      console.log('No active session');
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, userData: any) => {
    try {
      const response = await api.register({
        email,
        password,
        firstName: userData.firstName,
        lastName: userData.lastName,
        businessName: userData.businessName,
        phone: userData.phone
      });

      if (response.success) {
        // Auto login after registration
        return await signIn(email, password);
      }

      return response;
    } catch (error: any) {
      return { data: null, error: { message: error.message } };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      // Admin için özel kontrol
      if (email === 'nfcmenum@gmail.com' && password === 'kjkszpJ9.') {
        const adminUser = {
          id: 'admin-user-id',
          email: 'nfcmenum@gmail.com',
          firstName: 'Admin',
          lastName: 'User',
          businessName: 'NFCmenüm Admin',
          plan: 'admin'
        };
        setUser(adminUser);
        return { data: { user: adminUser }, error: null };
      }

      const response = await api.login(email, password);
      
      if (response.success) {
        setUser(response.data.user);
        return { data: response.data, error: null };
      }

      return { data: null, error: { message: response.error } };
    } catch (error: any) {
      return { data: null, error: { message: error.message } };
    }
  };

  const signOut = async () => {
    try {
      await api.logout();
    } catch (error) {
      console.log('Logout error:', error);
    } finally {
      setUser(null);
    }
  };

  const updateProfile = async (updates: any) => {
    try {
      const response = await api.updateProfile(updates);
      if (response.success) {
        setUser(prev => prev ? { ...prev, ...updates } : null);
        return true;
      }
      return false;
    } catch (error) {
      return false;
    }
  };

  const value = {
    user,
    loading,
    signUp,
    signIn,
    signOut,
    updateProfile,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}