import React from 'react';
import { QrCode, Nfc, Smartphone, Store, BarChart3, Palette, Shield, Zap, CheckCircle, Star, ArrowRight, Menu, X } from 'lucide-react';
import { Link } from 'react-router-dom';

function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const features = [
    {
      icon: QrCode,
      title: "QR Kod Menüleri",
      description: "Tüm cihazlarda çalışan evrensel QR kod menüleri oluşturun"
    },
    {
      icon: Nfc,
      title: "NFC Teknolojisi",
      description: "Tek dokunuşla menüye erişim sağlayan premium NFC deneyimi"
    },
    {
      icon: Smartphone,
      title: "Mobil Optimizasyon",
      description: "Mükemmel mobil deneyim için optimize edilmiş responsive tasarım"
    },
    {
      icon: Store,
      title: "Fiziksel Standlar",
      description: "QR ve NFC destekli özel tasarım masa standları"
    },
    {
      icon: BarChart3,
      title: "Detaylı Analytics",
      description: "Menü görüntüleme istatistikleri ve müşteri davranış analizi"
    },
    {
      icon: Palette,
      title: "Özel Tasarım",
      description: "Markanıza uygun renk, logo ve tema seçenekleri"
    }
  ];

  const plans = [
    {
      name: "Ücretsiz",
      price: "₺0",
      period: "/ay",
      features: [
        "1 Restoran",
        "QR Kod Menü",
        "10 Ürün Limiti",
        "Temel Şablonlar",
        "Email Destek"
      ],
      popular: false,
      buttonText: "Ücretsiz Başla",
      buttonLink: "/register"
    },
    {
      name: "Profesyonel",
      price: "₺299",
      period: "/ay",
      features: [
        "3 Restoran",
        "QR + NFC Menü",
        "Sınırsız Ürün",
        "Gelişmiş Analytics",
        "Özel Tasarım",
        "Öncelikli Destek",
        "2 Adet Ücretsiz Stand"
      ],
      popular: true,
      buttonText: "Pro'ya Geç",
      buttonLink: "/payment?plan=professional"
    },
    {
      name: "Kurumsal",
      price: "₺799",
      period: "/ay",
      features: [
        "Sınırsız Restoran",
        "Tüm Özellikler",
        "API Erişimi",
        "Özel Entegrasyonlar",
        "Dedicated Hesap Yöneticisi",
        "5 Adet Ücretsiz Stand",
        "Özel Eğitim"
      ],
      popular: false,
      buttonText: "Kurumsal Çözüm",
      buttonLink: "/payment?plan=enterprise"
    }
  ];

  const testimonials = [
    {
      name: "Mehmet Yılmaz",
      business: "Lezzet Durağı",
      content: "NFC standları sayesinde müşterilerimiz menüye çok kolay erişiyor. Sipariş süresi %40 azaldı!",
      rating: 5
    },
    {
      name: "Ayşe Kaya",
      business: "Cafe Bohem",
      content: "Hem QR hem NFC seçeneği sunmak müşteri memnuniyetini artırdı. Harika bir platform!",
      rating: 5
    },
    {
      name: "Can Özdemir",
      business: "Burger House",
      content: "Analytics özelliği sayesinde hangi ürünlerin daha çok ilgi gördüğünü takip edebiliyorum.",
      rating: 5
    }
  ];

  const standOptions = [
    {
      name: "Kompakt Masa Standı",
      price: "₺149",
      image: "https://images.pexels.com/photos/6205509/pexels-photo-6205509.jpeg?auto=compress&cs=tinysrgb&w=400",
      features: ["QR + NFC Destekli", "Kompakt Tasarım", "Dayanıklı Malzeme", "Kolay Kurulum"],
      description: "Küçük masalar için ideal, şık ve fonksiyonel tasarım"
    },
    {
      name: "Premium LED Stand",
      price: "₺299",
      image: "https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=400",
      features: ["LED Aydınlatma", "Premium Malzeme", "Ayarlanabilir Yükseklik", "Şarj Edilebilir"],
      description: "Gece kullanımı için LED aydınlatmalı premium stand"
    },
    {
      name: "Duvar Montajlı",
      price: "₺199",
      image: "https://images.pexels.com/photos/6205509/pexels-photo-6205509.jpeg?auto=compress&cs=tinysrgb&w=400",
      features: ["Sabit Montaj", "Vandalizm Koruması", "Weatherproof", "Kolay Temizlik"],
      description: "Sabit montaj için dayanıklı ve güvenli çözüm"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-sm shadow-sm sticky top-0 z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-orange-600 via-red-600 to-red-700 p-2.5 rounded-xl shadow-lg">
                <Nfc className="h-7 w-7 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
                NFCmenüm
              </span>
            </Link>
            
            <nav className="hidden md:flex space-x-6">
              <a href="#features" className="text-gray-700 hover:text-white hover:bg-orange-600 transition-all px-3 py-2 rounded-lg border border-transparent hover:border-orange-600 font-medium">Özellikler</a>
              <a href="#pricing" className="text-gray-700 hover:text-white hover:bg-orange-600 transition-all px-3 py-2 rounded-lg border border-transparent hover:border-orange-600 font-medium">Fiyatlandırma</a>
              <a href="#stands" className="text-gray-700 hover:text-white hover:bg-orange-600 transition-all px-3 py-2 rounded-lg border border-transparent hover:border-orange-600 font-medium">Standlar</a>
            </nav>

            <div className="hidden md:flex items-center space-x-4">
              <Link to="/login" className="text-gray-700 hover:text-orange-600 transition-colors font-medium">
                Giriş Yap
              </Link>
              <Link to="/register" className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-6 py-2.5 rounded-xl hover:shadow-lg transition-all transform hover:scale-105 font-medium">
                Ücretsiz Başla
              </Link>
            </div>

            <button 
              className="md:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100">
            <div className="px-4 py-4 space-y-3">
              <a href="#features" className="block py-2 text-gray-700 font-medium">Özellikler</a>
              <a href="#pricing" className="block py-2 text-gray-700 font-medium">Fiyatlandırma</a>
              <a href="#stands" className="block py-2 text-gray-700 font-medium">Standlar</a>
              <div className="pt-3 border-t border-gray-100 space-y-2">
                <Link to="/login" className="block py-2 text-gray-700 font-medium">Giriş Yap</Link>
                <Link to="/register" className="block w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-2.5 rounded-xl text-center font-medium">
                  Ücretsiz Başla
                </Link>
              </div>
            </div>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-orange-50 via-red-50 to-orange-100 py-20 overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-orange-200 to-red-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse"></div>
          <div className="absolute top-40 right-10 w-72 h-72 bg-gradient-to-r from-red-200 to-orange-200 rounded-full mix-blend-multiply filter blur-xl opacity-30 animate-pulse animation-delay-2000"></div>
          <div className="absolute -bottom-8 left-20 w-72 h-72 bg-gradient-to-r from-orange-300 to-red-300 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
        </div>
        
        {/* Subtle Pattern Overlay */}
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center">
            <div className="inline-flex items-center space-x-2 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full border border-orange-200 mb-8 shadow-lg">
              <Zap className="h-4 w-4 text-orange-600" />
              <span className="text-sm font-medium text-orange-600">Türkiye'nin İlk NFC Menü Platformu</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              Geleceğin Menü
              <span className="bg-gradient-to-r from-orange-600 via-red-600 to-red-700 bg-clip-text text-transparent block">
                Teknolojisi
              </span>
            </h1>
            
            <p className="text-xl text-gray-600 mb-10 max-w-3xl mx-auto leading-relaxed">
              QR kod ve NFC teknolojisini birleştiren akıllı menü sistemi ile restoranınızı dijital çağa taşıyın. 
              Müşterilerinize hem pratik hem de premium deneyim sunun.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
              <Link to="/register" className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-8 py-4 rounded-xl text-lg font-semibold hover:shadow-xl transition-all transform hover:scale-105 inline-flex items-center justify-center">
                Ücretsiz Başla
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link to="/contact" className="border-2 border-gray-300 text-gray-700 px-8 py-4 rounded-xl text-lg font-semibold hover:border-orange-600 hover:text-orange-600 transition-all bg-white/80 backdrop-blur-sm">
                Demo İzle
              </Link>
            </div>
          </div>

          {/* Hero Visual */}
          <div className="relative max-w-5xl mx-auto">
            <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border border-white/50">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="space-y-6">
                  <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200/50">
                    <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-3 rounded-lg shadow-lg">
                      <QrCode className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">QR Kod Menü</h3>
                      <p className="text-gray-600">Evrensel uyumluluk</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-200/50">
                    <div className="bg-gradient-to-r from-orange-500 to-red-600 p-3 rounded-lg shadow-lg">
                      <Nfc className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">NFC Erişim</h3>
                      <p className="text-gray-600">Tek dokunuşla menü</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200/50">
                    <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-3 rounded-lg shadow-lg">
                      <Zap className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">Hızlı Kurulum</h3>
                      <p className="text-gray-600">5 dakikada hazır</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8 text-center border border-gray-200/50">
                  <div className="bg-white rounded-xl p-6 shadow-lg">
                    <div className="w-32 h-32 bg-gradient-to-br from-orange-600 via-red-600 to-red-700 rounded-xl mx-auto mb-4 flex items-center justify-center shadow-lg">
                      <QrCode className="h-16 w-16 text-white" />
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">Örnek Menü</h4>
                    <p className="text-sm text-gray-600">QR kodu tarayın veya NFC ile dokunun</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gradient-to-br from-gray-50 via-white to-gray-50 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-10 right-20 w-64 h-64 bg-gradient-to-r from-orange-100 to-red-100 rounded-full mix-blend-multiply filter blur-2xl opacity-20"></div>
          <div className="absolute bottom-10 left-20 w-64 h-64 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full mix-blend-multiply filter blur-2xl opacity-20"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-orange-100 px-4 py-2 rounded-full mb-6">
              <Zap className="h-4 w-4 text-orange-600" />
              <span className="text-sm font-medium text-orange-600">Güçlü Özellikler</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Neden NFCmenüm?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Modern teknoloji ile geleneksel restoran deneyimini birleştiren kapsamlı çözümümüz
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="group relative bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:scale-105 border border-gray-100/50 hover:border-orange-200">
                {/* Gradient Border Effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10 blur-sm"></div>
                
                <div className="relative">
                  <div className="bg-gradient-to-r from-orange-600 to-red-600 p-4 rounded-xl w-fit mb-6 group-hover:scale-110 transition-transform shadow-lg">
                    <feature.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3 group-hover:text-orange-600 transition-colors">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Physical Stands Section */}
      <section id="stands" className="py-20 bg-gradient-to-br from-orange-50 via-red-50 to-orange-100 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-full h-full bg-grid-pattern opacity-5"></div>
          <div className="absolute top-20 left-10 w-72 h-72 bg-gradient-to-r from-orange-200 to-red-200 rounded-full mix-blend-multiply filter blur-xl opacity-20"></div>
          <div className="absolute bottom-20 right-10 w-72 h-72 bg-gradient-to-r from-red-200 to-orange-200 rounded-full mix-blend-multiply filter blur-xl opacity-20"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-white/90 backdrop-blur-sm px-4 py-2 rounded-full border border-orange-200 mb-6 shadow-lg">
              <Store className="h-4 w-4 text-orange-600" />
              <span className="text-sm font-medium text-orange-600">Fiziksel Çözümler</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Premium Fiziksel Standlar
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              QR kod ve NFC teknolojilerini birleştiren şık tasarım standlarımız
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {standOptions.map((stand, index) => (
              <div key={index} className="group bg-white/90 backdrop-blur-sm rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-500 transform hover:scale-105 border border-white/50">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={stand.image} 
                    alt={stand.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                  <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-1 rounded-full shadow-lg">
                    <span className="text-lg font-bold text-orange-600">{stand.price}</span>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-orange-600 transition-colors">{stand.name}</h3>
                  <p className="text-gray-600 mb-4">{stand.description}</p>
                  
                  <div className="space-y-2 mb-6">
                    {stand.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                        <span className="text-sm text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>
                  
                  <Link to="/contact" className="block w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-xl font-semibold hover:shadow-lg transition-all transform hover:scale-105 text-center">
                    Sipariş Ver
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Technology Showcase */}
      <section className="py-20 bg-white relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 left-10 w-96 h-96 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-gradient-to-r from-orange-100 to-red-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-100 to-orange-100 px-4 py-2 rounded-full mb-6">
              <QrCode className="h-4 w-4 text-blue-600" />
              <Nfc className="h-4 w-4 text-orange-600" />
              <span className="text-sm font-medium text-gray-700">Teknoloji Karşılaştırması</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              İki Teknoloji, Tek Platform
            </h2>
            <p className="text-xl text-gray-600">
              QR kod ve NFC teknolojilerinin avantajlarını birleştirdik
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-8 rounded-2xl border border-blue-200/50 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-3 rounded-xl shadow-lg">
                    <QrCode className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">QR Kod Avantajları</h3>
                </div>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Tüm akıllı telefonlarda çalışır</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Kamera ile kolay tarama</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Mesafeli erişim imkanı</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Düşük maliyet</li>
                </ul>
              </div>

              <div className="bg-gradient-to-r from-orange-50 to-red-50 p-8 rounded-2xl border border-orange-200/50 shadow-lg hover:shadow-xl transition-shadow">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="bg-gradient-to-r from-orange-500 to-red-600 p-3 rounded-xl shadow-lg">
                    <Nfc className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">NFC Avantajları</h3>
                </div>
                <ul className="space-y-3 text-gray-700">
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Tek dokunuşla anında erişim</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Premium müşteri deneyimi</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Hijyenik temassız kullanım</li>
                  <li className="flex items-center"><CheckCircle className="h-5 w-5 text-green-500 mr-3" />Modern ve şık görünüm</li>
                </ul>
              </div>
            </div>

            <div className="bg-white/90 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border border-gray-100/50">
              <h3 className="text-2xl font-bold text-center mb-8 text-gray-900">Karşılaştırma</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200/50">
                  <span className="font-medium text-gray-700">Kurulum Hızı</span>
                  <div className="flex space-x-2">
                    <span className="text-blue-600 font-semibold bg-blue-100 px-2 py-1 rounded-lg">QR: 1 dk</span>
                    <span className="text-orange-600 font-semibold bg-orange-100 px-2 py-1 rounded-lg">NFC: 2 dk</span>
                  </div>
                </div>
                <div className="flex justify-between items-center p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200/50">
                  <span className="font-medium text-gray-700">Kullanım Kolaylığı</span>
                  <div className="flex space-x-2">
                    <span className="text-blue-600 font-semibold">QR: ★★★★☆</span>
                    <span className="text-orange-600 font-semibold">NFC: ★★★★★</span>
                  </div>
                </div>
                <div className="flex justify-between items-center p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200/50">
                  <span className="font-medium text-gray-700">Premium Hissi</span>
                  <div className="flex space-x-2">
                    <span className="text-blue-600 font-semibold">QR: ★★★☆☆</span>
                    <span className="text-orange-600 font-semibold">NFC: ★★★★★</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gradient-to-br from-gray-50 via-white to-gray-50 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-72 h-72 bg-gradient-to-r from-purple-100 to-blue-100 rounded-full mix-blend-multiply filter blur-2xl opacity-20"></div>
          <div className="absolute bottom-10 right-10 w-72 h-72 bg-gradient-to-r from-orange-100 to-red-100 rounded-full mix-blend-multiply filter blur-2xl opacity-20"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-orange-100 to-red-100 px-4 py-2 rounded-full mb-6">
              <Shield className="h-4 w-4 text-orange-600" />
              <span className="text-sm font-medium text-orange-600">Esnek Fiyatlandırma</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Size Uygun Planı Seçin
            </h2>
            <p className="text-xl text-gray-600">
              Her büyüklükteki işletme için uygun fiyatlı çözümler
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {plans.map((plan, index) => (
              <div key={index} className={`group relative bg-white/90 backdrop-blur-sm rounded-3xl shadow-xl p-8 transition-all duration-500 hover:shadow-2xl border ${plan.popular ? 'ring-2 ring-orange-500 scale-105 transform border-orange-200' : 'hover:scale-105 border-gray-200/50'}`}>
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-6 py-2 rounded-full text-sm font-semibold shadow-lg">
                      En Popüler
                    </span>
                  </div>
                )}
                
                {/* Gradient Border Effect for Popular Plan */}
                {plan.popular && (
                  <div className="absolute inset-0 bg-gradient-to-r from-orange-600 to-red-600 rounded-3xl opacity-10 group-hover:opacity-20 transition-opacity duration-500"></div>
                )}
                
                <div className="relative">
                  <div className="text-center mb-8">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                    <div className="flex items-center justify-center mb-4">
                      <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                      <span className="text-gray-600 ml-2">{plan.period}</span>
                    </div>
                  </div>
                  
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link to={plan.buttonLink} className={`block w-full py-4 rounded-xl font-semibold text-center transition-all transform hover:scale-105 ${
                    plan.popular 
                      ? 'bg-gradient-to-r from-orange-600 to-red-600 text-white hover:shadow-lg' 
                      : 'border-2 border-gray-300 text-gray-700 hover:border-orange-600 hover:text-orange-600 bg-white/80 backdrop-blur-sm'
                  }`}>
                    {plan.buttonText}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20 bg-white relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-64 h-64 bg-gradient-to-r from-yellow-100 to-orange-100 rounded-full mix-blend-multiply filter blur-2xl opacity-30"></div>
          <div className="absolute bottom-20 left-20 w-64 h-64 bg-gradient-to-r from-green-100 to-blue-100 rounded-full mix-blend-multiply filter blur-2xl opacity-30"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 bg-gradient-to-r from-yellow-100 to-orange-100 px-4 py-2 rounded-full mb-6">
              <Star className="h-4 w-4 text-yellow-600" />
              <span className="text-sm font-medium text-yellow-600">Müşteri Yorumları</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Müşterilerimiz Ne Diyor?
            </h2>
            <p className="text-xl text-gray-600">
              Binlerce restoran NFCmenüm ile dijital dönüşümünü tamamladı
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="group bg-gradient-to-br from-white to-gray-50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 border border-gray-100/50 hover:border-orange-200 transform hover:scale-105">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-6 italic leading-relaxed">"{testimonial.content}"</p>
                <div className="border-t border-gray-200 pt-4">
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-orange-600 text-sm font-medium">{testimonial.business}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-orange-600 via-red-600 to-red-700 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8 relative">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Restoranınızı Dijital Çağa Taşıyın
          </h2>
          <p className="text-xl text-orange-100 mb-8">
            Ücretsiz plan ile başlayın. Kredi kartı gerektirmez.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register" className="bg-white text-orange-600 px-8 py-4 rounded-xl text-lg font-semibold hover:shadow-xl transition-all transform hover:scale-105 inline-flex items-center justify-center">
              Ücretsiz Başla
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link to="/contact" className="border-2 border-white text-white px-8 py-4 rounded-xl text-lg font-semibold hover:bg-white hover:text-orange-600 transition-all">
              Demo Talep Et
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-gradient-to-br from-orange-600 via-red-600 to-red-700 p-2.5 rounded-xl">
                  <Nfc className="h-6 w-6 text-white" />
                </div>
                <span className="text-xl font-bold">NFCmenüm</span>
              </div>
              <p className="text-gray-400 leading-relaxed">
                QR kod ve NFC teknolojisi ile restoranları geleceğe taşıyoruz.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Ürün</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#features" className="hover:text-white transition-colors">Özellikler</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">Fiyatlandırma</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Entegrasyonlar</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Destek</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Yardım Merkezi</a></li>
                <li><Link to="/contact" className="hover:text-white transition-colors">İletişim</Link></li>
                <li><a href="#" className="hover:text-white transition-colors">Canlı Destek</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Eğitim</a></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Şirket</h3>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Hakkımızda</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
                <li><Link to="/contact" className="hover:text-white transition-colors">Referanslar</Link></li>
                <li><a href="#" className="hover:text-white transition-colors">Basın</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 NFCmenüm. Tüm hakları saklıdır.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default LandingPage;