import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Settings, 
  Users, 
  DollarSign, 
  Package,
  BarChart3,
  Edit,
  Save,
  X,
  Plus,
  Trash2,
  Shield,
  TrendingUp,
  Eye,
  Calendar,
  Download,
  Search,
  Filter,
  UserCheck,
  UserX,
  Crown,
  Mail,
  Phone,
  Building,
  Activity,
  Target,
  Zap,
  Globe,
  Clock,
  CheckCircle,
  AlertCircle,
  XCircle
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Plan {
  id: string;
  name: string;
  price: number;
  features: string[];
  popular: boolean;
  active: boolean;
}

interface Stand {
  id: string;
  name: string;
  price: number;
  image_url: string;
  features: string[];
  description: string;
  active: boolean;
}

interface User {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  business_name: string;
  phone: string;
  plan: string;
  status: 'active' | 'inactive' | 'suspended';
  created_at: string;
  last_login: string;
  restaurants_count: number;
  total_views: number;
}

interface AnalyticsData {
  totalUsers: number;
  activeUsers: number;
  totalRevenue: number;
  monthlyGrowth: number;
  planDistribution: { [key: string]: number };
  monthlyStats: { month: string; users: number; revenue: number }[];
  topRestaurants: { name: string; views: number; owner: string }[];
  recentActivity: { type: string; description: string; time: string }[];
}

function AdminPanel() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('analytics');
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [editingStand, setEditingStand] = useState<Stand | null>(null);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  // Admin kontrolü
  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    
    const adminEmails = ['admin@nfcmenum.com', 'nfcmenum@gmail.com', 'test@admin.com'];
    if (!adminEmails.includes(user.email || '')) {
      navigate('/dashboard');
      return;
    }
  }, [user, navigate]);

  // Demo Analytics Data
  const [analyticsData] = useState<AnalyticsData>({
    totalUsers: 1247,
    activeUsers: 892,
    totalRevenue: 186750,
    monthlyGrowth: 23.5,
    planDistribution: {
      'Ücretsiz': 687,
      'Profesyonel': 421,
      'Kurumsal': 139
    },
    monthlyStats: [
      { month: 'Oca', users: 156, revenue: 12400 },
      { month: 'Şub', users: 189, revenue: 15600 },
      { month: 'Mar', users: 234, revenue: 18900 },
      { month: 'Nis', users: 267, revenue: 22100 },
      { month: 'May', users: 298, revenue: 25800 },
      { month: 'Haz', users: 334, revenue: 28900 }
    ],
    topRestaurants: [
      { name: 'Lezzet Durağı', views: 15420, owner: 'Mehmet Yılmaz' },
      { name: 'Cafe Bohem', views: 12890, owner: 'Ayşe Kaya' },
      { name: 'Burger House', views: 11230, owner: 'Can Özdemir' },
      { name: 'Pizza Corner', views: 9870, owner: 'Elif Demir' },
      { name: 'Sushi Bar', views: 8650, owner: 'Kemal Arslan' }
    ],
    recentActivity: [
      { type: 'user_register', description: 'Yeni kullanıcı kaydı: Zeynep Kara', time: '5 dakika önce' },
      { type: 'plan_upgrade', description: 'Plan yükseltme: Profesyonel → Kurumsal', time: '12 dakika önce' },
      { type: 'restaurant_create', description: 'Yeni restoran eklendi: Deniz Restaurant', time: '23 dakika önce' },
      { type: 'payment', description: 'Ödeme alındı: ₺299 - Profesyonel Plan', time: '1 saat önce' },
      { type: 'support', description: 'Destek talebi oluşturuldu: NFC sorunu', time: '2 saat önce' }
    ]
  });

  // Demo Plans Data
  const [plans, setPlans] = useState<Plan[]>([
    {
      id: '1',
      name: 'Ücretsiz',
      price: 0,
      features: ['1 Restoran', 'QR Kod Menü', '10 Ürün Limiti', 'Temel Şablonlar', 'Email Destek'],
      popular: false,
      active: true
    },
    {
      id: '2',
      name: 'Profesyonel',
      price: 299,
      features: ['3 Restoran', 'QR + NFC Menü', 'Sınırsız Ürün', 'Gelişmiş Analytics', 'Özel Tasarım', 'Öncelikli Destek', '2 Adet Ücretsiz Stand'],
      popular: true,
      active: true
    },
    {
      id: '3',
      name: 'Kurumsal',
      price: 799,
      features: ['Sınırsız Restoran', 'Tüm Özellikler', 'API Erişimi', 'Özel Entegrasyonlar', 'Dedicated Hesap Yöneticisi', '5 Adet Ücretsiz Stand', 'Özel Eğitim'],
      popular: false,
      active: true
    }
  ]);

  // Demo Stands Data
  const [stands, setStands] = useState<Stand[]>([
    {
      id: '1',
      name: 'Kompakt Masa Standı',
      price: 149,
      image_url: 'https://images.pexels.com/photos/6205509/pexels-photo-6205509.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['QR + NFC Destekli', 'Kompakt Tasarım', 'Dayanıklı Malzeme', 'Kolay Kurulum'],
      description: 'Küçük masalar için ideal, şık ve fonksiyonel tasarım',
      active: true
    },
    {
      id: '2',
      name: 'Premium LED Stand',
      price: 299,
      image_url: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['LED Aydınlatma', 'Premium Malzeme', 'Ayarlanabilir Yükseklik', 'Şarj Edilebilir'],
      description: 'Gece kullanımı için LED aydınlatmalı premium stand',
      active: true
    },
    {
      id: '3',
      name: 'Duvar Montajlı',
      price: 199,
      image_url: 'https://images.pexels.com/photos/6205509/pexels-photo-6205509.jpeg?auto=compress&cs=tinysrgb&w=400',
      features: ['Sabit Montaj', 'Vandalizm Koruması', 'Weatherproof', 'Kolay Temizlik'],
      description: 'Sabit montaj için dayanıklı ve güvenli çözüm',
      active: true
    }
  ]);

  // Demo Users Data
  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      email: 'mehmet@lezzetduragi.com',
      first_name: 'Mehmet',
      last_name: 'Yılmaz',
      business_name: 'Lezzet Durağı',
      phone: '+90 532 123 4567',
      plan: 'Profesyonel',
      status: 'active',
      created_at: '2024-01-15',
      last_login: '2024-01-20 14:30',
      restaurants_count: 2,
      total_views: 15420
    },
    {
      id: '2',
      email: 'ayse@cafebohem.com',
      first_name: 'Ayşe',
      last_name: 'Kaya',
      business_name: 'Cafe Bohem',
      phone: '+90 533 987 6543',
      plan: 'Kurumsal',
      status: 'active',
      created_at: '2024-01-10',
      last_login: '2024-01-20 16:45',
      restaurants_count: 3,
      total_views: 12890
    },
    {
      id: '3',
      email: 'can@burgerhouse.com',
      first_name: 'Can',
      last_name: 'Özdemir',
      business_name: 'Burger House',
      phone: '+90 534 555 1234',
      plan: 'Ücretsiz',
      status: 'inactive',
      created_at: '2024-01-05',
      last_login: '2024-01-18 10:15',
      restaurants_count: 1,
      total_views: 11230
    },
    {
      id: '4',
      email: 'elif@pizzacorner.com',
      first_name: 'Elif',
      last_name: 'Demir',
      business_name: 'Pizza Corner',
      phone: '+90 535 777 8888',
      plan: 'Profesyonel',
      status: 'active',
      created_at: '2024-01-12',
      last_login: '2024-01-20 12:20',
      restaurants_count: 2,
      total_views: 9870
    },
    {
      id: '5',
      email: 'kemal@sushibar.com',
      first_name: 'Kemal',
      last_name: 'Arslan',
      business_name: 'Sushi Bar',
      phone: '+90 536 999 0000',
      plan: 'Profesyonel',
      status: 'suspended',
      created_at: '2024-01-08',
      last_login: '2024-01-19 18:30',
      restaurants_count: 1,
      total_views: 8650
    }
  ]);

  const handleSavePlan = (plan: Plan) => {
    if (plan.id) {
      setPlans(plans.map(p => p.id === plan.id ? plan : p));
    } else {
      const newPlan = { ...plan, id: Date.now().toString() };
      setPlans([...plans, newPlan]);
    }
    setEditingPlan(null);
  };

  const handleSaveStand = (stand: Stand) => {
    if (stand.id) {
      setStands(stands.map(s => s.id === stand.id ? stand : s));
    } else {
      const newStand = { ...stand, id: Date.now().toString() };
      setStands([...stands, newStand]);
    }
    setEditingStand(null);
  };

  const handleSaveUser = (user: User) => {
    setUsers(users.map(u => u.id === user.id ? user : u));
    setEditingUser(null);
  };

  const handleDeletePlan = (planId: string) => {
    if (!confirm('Bu planı silmek istediğinizden emin misiniz?')) return;
    setPlans(plans.filter(p => p.id !== planId));
  };

  const handleDeleteStand = (standId: string) => {
    if (!confirm('Bu standı silmek istediğinizden emin misiniz?')) return;
    setStands(stands.filter(s => s.id !== standId));
  };

  const handleDeleteUser = (userId: string) => {
    if (!confirm('Bu kullanıcıyı silmek istediğinizden emin misiniz?')) return;
    setUsers(users.filter(u => u.id !== userId));
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.first_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.last_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.business_name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = filterStatus === 'all' || user.status === filterStatus;
    
    return matchesSearch && matchesFilter;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'inactive': return <AlertCircle className="h-4 w-4 text-yellow-500" />;
      case 'suspended': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const baseClasses = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium";
    switch (status) {
      case 'active':
        return `${baseClasses} bg-green-100 text-green-800`;
      case 'inactive':
        return `${baseClasses} bg-yellow-100 text-yellow-800`;
      case 'suspended':
        return `${baseClasses} bg-red-100 text-red-800`;
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`;
    }
  };

  const getPlanBadge = (plan: string) => {
    const baseClasses = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium";
    switch (plan) {
      case 'Kurumsal':
        return `${baseClasses} bg-purple-100 text-purple-800`;
      case 'Profesyonel':
        return `${baseClasses} bg-orange-100 text-orange-800`;
      case 'Ücretsiz':
        return `${baseClasses} bg-gray-100 text-gray-800`;
      default:
        return `${baseClasses} bg-gray-100 text-gray-800`;
    }
  };

  const tabs = [
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'users', label: 'Kullanıcılar', icon: Users },
    { id: 'plans', label: 'Planlar', icon: DollarSign },
    { id: 'stands', label: 'Standlar', icon: Package }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-br from-orange-600 via-red-600 to-red-700 p-2 rounded-lg">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold text-gray-900">Admin Panel</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Admin: {user?.email}</span>
              <button
                onClick={() => navigate('/dashboard')}
                className="text-gray-600 hover:text-gray-900 bg-gray-100 px-4 py-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Dashboard'a Dön
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="-mb-px flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-2 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-orange-500 text-orange-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <Users className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Toplam Kullanıcı</p>
                    <p className="text-2xl font-bold text-gray-900">{analyticsData.totalUsers.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <UserCheck className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Aktif Kullanıcı</p>
                    <p className="text-2xl font-bold text-gray-900">{analyticsData.activeUsers.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center">
                  <div className="bg-orange-100 p-3 rounded-lg">
                    <DollarSign className="h-6 w-6 text-orange-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Toplam Gelir</p>
                    <p className="text-2xl font-bold text-gray-900">₺{analyticsData.totalRevenue.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-shadow">
                <div className="flex items-center">
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-purple-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Aylık Büyüme</p>
                    <p className="text-2xl font-bold text-gray-900">%{analyticsData.monthlyGrowth}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Charts and Tables */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Plan Distribution */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Plan Dağılımı</h3>
                <div className="space-y-4">
                  {Object.entries(analyticsData.planDistribution).map(([plan, count]) => (
                    <div key={plan} className="flex items-center justify-between">
                      <span className="text-gray-700">{plan}</span>
                      <div className="flex items-center space-x-3">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-orange-600 h-2 rounded-full" 
                            style={{ width: `${(count / analyticsData.totalUsers) * 100}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium text-gray-900 w-12 text-right">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Top Restaurants */}
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">En Çok Görüntülenen Restoranlar</h3>
                <div className="space-y-3">
                  {analyticsData.topRestaurants.map((restaurant, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div>
                        <p className="font-medium text-gray-900">{restaurant.name}</p>
                        <p className="text-sm text-gray-600">{restaurant.owner}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-orange-600">{restaurant.views.toLocaleString()}</p>
                        <p className="text-xs text-gray-500">görüntüleme</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold text-gray-900">Son Aktiviteler</h3>
                <button className="text-orange-600 hover:text-orange-700 text-sm font-medium">
                  Tümünü Gör
                </button>
              </div>
              <div className="space-y-4">
                {analyticsData.recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                    <div className="bg-orange-100 p-2 rounded-lg">
                      <Activity className="h-4 w-4 text-orange-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-gray-900">{activity.description}</p>
                      <p className="text-sm text-gray-500">{activity.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Users Tab */}
        {activeTab === 'users' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Kullanıcı Yönetimi</h2>
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Kullanıcı ara..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="all">Tüm Durumlar</option>
                  <option value="active">Aktif</option>
                  <option value="inactive">Pasif</option>
                  <option value="suspended">Askıya Alınmış</option>
                </select>
                <button className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 inline-flex items-center">
                  <Download className="h-4 w-4 mr-2" />
                  Dışa Aktar
                </button>
              </div>
            </div>

            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Kullanıcı
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        İşletme
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Plan
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Durum
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Restoranlar
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Görüntüleme
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Son Giriş
                      </th>
                      <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        İşlemler
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div>
                            <div className="text-sm font-medium text-gray-900">
                              {user.first_name} {user.last_name}
                            </div>
                            <div className="text-sm text-gray-500">{user.email}</div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{user.business_name}</div>
                          <div className="text-sm text-gray-500">{user.phone}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={getPlanBadge(user.plan)}>
                            {user.plan}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={getStatusBadge(user.status)}>
                            {getStatusIcon(user.status)}
                            <span className="ml-1">
                              {user.status === 'active' ? 'Aktif' : 
                               user.status === 'inactive' ? 'Pasif' : 'Askıya Alınmış'}
                            </span>
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {user.restaurants_count}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {user.total_views.toLocaleString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {user.last_login}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex items-center justify-end space-x-2">
                            <button
                              onClick={() => setEditingUser(user)}
                              className="text-orange-600 hover:text-orange-900 p-1 hover:bg-orange-50 rounded transition-colors"
                              title="Düzenle"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteUser(user.id)}
                              className="text-red-600 hover:text-red-900 p-1 hover:bg-red-50 rounded transition-colors"
                              title="Sil"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Plans Tab */}
        {activeTab === 'plans' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Plan Yönetimi</h2>
              <button
                onClick={() => setEditingPlan({
                  id: '',
                  name: '',
                  price: 0,
                  features: [],
                  popular: false,
                  active: true
                })}
                className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 inline-flex items-center transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Yeni Plan
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {plans.map((plan) => (
                <div key={plan.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">{plan.name}</h3>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setEditingPlan(plan)}
                        className="p-2 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded transition-colors"
                        title="Düzenle"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDeletePlan(plan.id)}
                        className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                        title="Sil"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="text-3xl font-bold text-gray-900 mb-4">
                    ₺{plan.price}<span className="text-sm text-gray-600">/ay</span>
                  </div>
                  
                  <ul className="space-y-2 mb-4">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="text-sm text-gray-600 flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                  
                  <div className="flex items-center space-x-2">
                    {plan.popular && (
                      <span className="bg-orange-100 text-orange-800 text-xs px-2 py-1 rounded-full">
                        Popüler
                      </span>
                    )}
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      plan.active 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {plan.active ? 'Aktif' : 'Pasif'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Stands Tab */}
        {activeTab === 'stands' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Stand Yönetimi</h2>
              <button
                onClick={() => setEditingStand({
                  id: '',
                  name: '',
                  price: 0,
                  image_url: '',
                  features: [],
                  description: '',
                  active: true
                })}
                className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 inline-flex items-center transition-colors"
              >
                <Plus className="h-4 w-4 mr-2" />
                Yeni Stand
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {stands.map((stand) => (
                <div key={stand.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={stand.image_url} 
                      alt={stand.name}
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
                    />
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full">
                      <span className="text-lg font-bold text-orange-600">₺{stand.price}</span>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">{stand.name}</h3>
                      <div className="flex space-x-2">
                        <button
                          onClick={() => setEditingStand(stand)}
                          className="p-2 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded transition-colors"
                          title="Düzenle"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteStand(stand.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                          title="Sil"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 text-sm mb-4">{stand.description}</p>
                    
                    <ul className="space-y-1 mb-4">
                      {stand.features.map((feature, index) => (
                        <li key={index} className="text-xs text-gray-600 flex items-center">
                          <CheckCircle className="h-3 w-3 text-green-500 mr-2 flex-shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      stand.active 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {stand.active ? 'Aktif' : 'Pasif'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Edit Plan Modal */}
      {editingPlan && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900">
                {editingPlan.id ? 'Planı Düzenle' : 'Yeni Plan'}
              </h3>
              <button
                onClick={() => setEditingPlan(null)}
                className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Plan Adı
                </label>
                <input
                  type="text"
                  value={editingPlan.name}
                  onChange={(e) => setEditingPlan({ ...editingPlan, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Fiyat (₺)
                </label>
                <input
                  type="number"
                  value={editingPlan.price}
                  onChange={(e) => setEditingPlan({ ...editingPlan, price: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Özellikler (her satıra bir özellik)
                </label>
                <textarea
                  value={editingPlan.features.join('\n')}
                  onChange={(e) => setEditingPlan({ 
                    ...editingPlan, 
                    features: e.target.value.split('\n').filter(f => f.trim()) 
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  rows={5}
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={editingPlan.popular}
                    onChange={(e) => setEditingPlan({ ...editingPlan, popular: e.target.checked })}
                    className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Popüler Plan</span>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={editingPlan.active}
                    onChange={(e) => setEditingPlan({ ...editingPlan, active: e.target.checked })}
                    className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Aktif</span>
                </label>
              </div>
              
              <div className="flex space-x-4 pt-4">
                <button
                  onClick={() => setEditingPlan(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  İptal
                </button>
                <button
                  onClick={() => handleSavePlan(editingPlan)}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 inline-flex items-center justify-center transition-colors"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Stand Modal */}
      {editingStand && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900">
                {editingStand.id ? 'Standı Düzenle' : 'Yeni Stand'}
              </h3>
              <button
                onClick={() => setEditingStand(null)}
                className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Stand Adı
                </label>
                <input
                  type="text"
                  value={editingStand.name}
                  onChange={(e) => setEditingStand({ ...editingStand, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Fiyat (₺)
                </label>
                <input
                  type="number"
                  value={editingStand.price}
                  onChange={(e) => setEditingStand({ ...editingStand, price: Number(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Resim URL
                </label>
                <input
                  type="url"
                  value={editingStand.image_url}
                  onChange={(e) => setEditingStand({ ...editingStand, image_url: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Açıklama
                </label>
                <textarea
                  value={editingStand.description}
                  onChange={(e) => setEditingStand({ ...editingStand, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  rows={3}
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Özellikler (her satıra bir özellik)
                </label>
                <textarea
                  value={editingStand.features.join('\n')}
                  onChange={(e) => setEditingStand({ 
                    ...editingStand, 
                    features: e.target.value.split('\n').filter(f => f.trim()) 
                  })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  rows={4}
                />
              </div>
              
              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={editingStand.active}
                    onChange={(e) => setEditingStand({ ...editingStand, active: e.target.checked })}
                    className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Aktif</span>
                </label>
              </div>
              
              <div className="flex space-x-4 pt-4">
                <button
                  onClick={() => setEditingStand(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  İptal
                </button>
                <button
                  onClick={() => handleSaveStand(editingStand)}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 inline-flex items-center justify-center transition-colors"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900">Kullanıcı Düzenle</h3>
              <button
                onClick={() => setEditingUser(null)}
                className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Ad</label>
                  <input
                    type="text"
                    value={editingUser.first_name}
                    onChange={(e) => setEditingUser({ ...editingUser, first_name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Soyad</label>
                  <input
                    type="text"
                    value={editingUser.last_name}
                    onChange={(e) => setEditingUser({ ...editingUser, last_name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">E-posta</label>
                <input
                  type="email"
                  value={editingUser.email}
                  onChange={(e) => setEditingUser({ ...editingUser, email: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">İşletme Adı</label>
                <input
                  type="text"
                  value={editingUser.business_name}
                  onChange={(e) => setEditingUser({ ...editingUser, business_name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
                <input
                  type="tel"
                  value={editingUser.phone}
                  onChange={(e) => setEditingUser({ ...editingUser, phone: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Plan</label>
                <select
                  value={editingUser.plan}
                  onChange={(e) => setEditingUser({ ...editingUser, plan: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="Ücretsiz">Ücretsiz</option>
                  <option value="Profesyonel">Profesyonel</option>
                  <option value="Kurumsal">Kurumsal</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Durum</label>
                <select
                  value={editingUser.status}
                  onChange={(e) => setEditingUser({ ...editingUser, status: e.target.value as 'active' | 'inactive' | 'suspended' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  <option value="active">Aktif</option>
                  <option value="inactive">Pasif</option>
                  <option value="suspended">Askıya Alınmış</option>
                </select>
              </div>
              
              <div className="flex space-x-4 pt-4">
                <button
                  onClick={() => setEditingUser(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  İptal
                </button>
                <button
                  onClick={() => handleSaveUser(editingUser)}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 inline-flex items-center justify-center transition-colors"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminPanel;