import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { 
  Clock, 
  Star, 
  DollarSign,
  Nfc,
  QrCode,
  Search,
  Heart,
  Share2,
  Phone,
  MapPin,
  Globe,
  ShoppingCart,
  Bell
} from 'lucide-react';
import { api } from '../lib/api';

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url?: string;
  available: boolean;
  featured: boolean;
  preparation_time?: number;
}

interface MenuCategory {
  id: string;
  name: string;
  description?: string;
  order: number;
}

interface Restaurant {
  id: string;
  name: string;
  description: string;
  logo_url?: string;
  theme_color: string;
  phone?: string;
  address?: string;
  website?: string;
  created_at: string;
}

function MenuView() {
  const { restaurantId } = useParams();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [categories, setCategories] = useState<MenuCategory[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [restaurantId]);

  const loadData = async () => {
    if (!restaurantId) return;

    try {
      // Track menu view
      await api.trackMenuView(restaurantId);

      const [restaurantRes, menuRes] = await Promise.all([
        api.getRestaurant(restaurantId),
        api.getPublicMenu(restaurantId)
      ]);

      if (restaurantRes.success) {
        setRestaurant(restaurantRes.data);
      }

      if (menuRes.success) {
        setCategories(menuRes.data.categories || []);
        setMenuItems(menuRes.data.items || []);
      }
    } catch (error) {
      console.error('Error loading menu:', error);
      // Fallback to demo data
      setRestaurant({
        id: restaurantId || '1',
        name: 'Lezzet Durağı',
        description: 'Geleneksel Türk mutfağı ile modern lezzetlerin buluştuğu nokta',
        theme_color: '#ea580c',
        phone: '+90 212 123 45 67',
        address: 'Beyoğlu, İstanbul',
        website: 'www.lezzetduragi.com',
        created_at: new Date().toISOString()
      });

      setCategories([
        { id: '1', name: 'Başlangıçlar', description: 'Lezzetli başlangıç yemekleri', order: 1 },
        { id: '2', name: 'Ana Yemekler', description: 'Doyurucu ana yemekler', order: 2 },
        { id: '3', name: 'Tatlılar', description: 'Tatlı son', order: 3 },
        { id: '4', name: 'İçecekler', description: 'Serinletici içecekler', order: 4 }
      ]);

      setMenuItems([
        {
          id: '1',
          name: 'Mercimek Çorbası',
          description: 'Geleneksel Türk mercimek çorbası, taze nane ile servis edilir',
          price: 25,
          category: 'Başlangıçlar',
          available: true,
          featured: true,
          preparation_time: 10,
          image_url: 'https://images.pexels.com/photos/539451/pexels-photo-539451.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '2',
          name: 'Adana Kebap',
          description: 'Acılı kıyma kebabı, bulgur pilavı ve mevsim salata ile',
          price: 85,
          category: 'Ana Yemekler',
          available: true,
          featured: true,
          preparation_time: 20,
          image_url: 'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '3',
          name: 'Urfa Kebap',
          description: 'Acısız kıyma kebabı, bulgur pilavı ve mevsim salata ile',
          price: 80,
          category: 'Ana Yemekler',
          available: true,
          featured: false,
          preparation_time: 20,
          image_url: 'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '4',
          name: 'Baklava',
          description: 'Antep fıstıklı geleneksel baklava, 4 adet',
          price: 35,
          category: 'Tatlılar',
          available: true,
          featured: false,
          preparation_time: 5,
          image_url: 'https://images.pexels.com/photos/8477552/pexels-photo-8477552.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '5',
          name: 'Künefe',
          description: 'Hatay usulü künefe, dondurma ile servis',
          price: 45,
          category: 'Tatlılar',
          available: true,
          featured: true,
          preparation_time: 15,
          image_url: 'https://images.pexels.com/photos/8477552/pexels-photo-8477552.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '6',
          name: 'Türk Kahvesi',
          description: 'Geleneksel Türk kahvesi, lokum ile servis',
          price: 20,
          category: 'İçecekler',
          available: true,
          featured: false,
          preparation_time: 8,
          image_url: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '7',
          name: 'Çay',
          description: 'Geleneksel Türk çayı, ince belli bardakta',
          price: 8,
          category: 'İçecekler',
          available: true,
          featured: false,
          preparation_time: 3,
          image_url: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '8',
          name: 'Ayran',
          description: 'Ev yapımı taze ayran',
          price: 12,
          category: 'İçecekler',
          available: true,
          featured: false,
          preparation_time: 2,
          image_url: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const filteredItems = menuItems.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch && item.available;
  });

  const featuredItems = menuItems.filter(item => item.featured && item.available);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{restaurant?.name}</h1>
            <p className="text-gray-600 mb-4">{restaurant?.description}</p>
            
            <div className="flex items-center justify-center space-x-6 text-sm text-gray-600">
              {restaurant?.phone && (
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-1" />
                  {restaurant.phone}
                </div>
              )}
              {restaurant?.address && (
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  {restaurant.address}
                </div>
              )}
              {restaurant?.website && (
                <div className="flex items-center">
                  <Globe className="h-4 w-4 mr-1" />
                  {restaurant.website}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Action Buttons */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <Link 
            to={`/menu/${restaurantId}/order`}
            className="bg-gradient-to-r from-orange-600 to-red-600 text-white py-4 rounded-xl hover:shadow-lg transition-all transform hover:scale-105 font-semibold text-center inline-flex items-center justify-center"
          >
            <ShoppingCart className="h-5 w-5 mr-2" />
            Sipariş Ver
          </Link>
          <Link 
            to={`/menu/${restaurantId}/waiter`}
            className="bg-blue-600 text-white py-4 rounded-xl hover:shadow-lg transition-all transform hover:scale-105 font-semibold text-center inline-flex items-center justify-center"
          >
            <Bell className="h-5 w-5 mr-2" />
            Garson Çağır
          </Link>
        </div>

        {/* Search and Filter */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8 border border-gray-100">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="h-5 w-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Menüde ara..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              />
            </div>
            
            <div className="md:w-48">
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
              >
                <option value="all">Tüm Kategoriler</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.name}>{category.name}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Featured Items */}
        {featuredItems.length > 0 && selectedCategory === 'all' && !searchTerm && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <Star className="h-6 w-6 text-yellow-500 mr-2" />
              Öne Çıkan Lezzetler
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {featuredItems.map((item) => (
                <div key={item.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
                  <div className="flex">
                    <div className="w-32 h-32 flex-shrink-0">
                      {item.image_url ? (
                        <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                          <DollarSign className="h-8 w-8 text-gray-400" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 p-4">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-gray-900 flex items-center">
                          {item.name}
                          <Star className="h-4 w-4 text-yellow-500 ml-1" />
                        </h3>
                        <span className="text-lg font-bold text-orange-600">₺{item.price}</span>
                      </div>
                      <p className="text-sm text-gray-600 mb-3">{item.description}</p>
                      {item.preparation_time && (
                        <div className="flex items-center text-xs text-gray-500">
                          <Clock className="h-3 w-3 mr-1" />
                          {item.preparation_time} dakika
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Menu Categories */}
        {categories.map((category) => {
          const categoryItems = filteredItems.filter(item => item.category === category.name);
          if (categoryItems.length === 0) return null;

          return (
            <div key={category.id} className="mb-8">
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
                <div className="bg-gradient-to-r from-orange-600 to-red-600 px-6 py-4">
                  <h2 className="text-xl font-bold text-white">{category.name}</h2>
                  {category.description && (
                    <p className="text-orange-100 text-sm mt-1">{category.description}</p>
                  )}
                </div>
                
                <div className="p-6">
                  <div className="grid gap-4">
                    {categoryItems.map((item) => (
                      <div key={item.id} className="flex items-start space-x-4 p-4 hover:bg-gray-50 rounded-lg transition-colors">
                        <div className="w-20 h-20 flex-shrink-0 rounded-lg overflow-hidden">
                          {item.image_url ? (
                            <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                              <DollarSign className="h-6 w-6 text-gray-400" />
                            </div>
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="font-semibold text-gray-900 flex items-center">
                              {item.name}
                              {item.featured && <Star className="h-4 w-4 text-yellow-500 ml-1" />}
                            </h3>
                            <span className="text-xl font-bold text-orange-600 ml-4">₺{item.price}</span>
                          </div>
                          
                          <p className="text-gray-600 text-sm mb-3 leading-relaxed">{item.description}</p>
                          
                          <div className="flex items-center justify-between">
                            {item.preparation_time && (
                              <div className="flex items-center text-xs text-gray-500">
                                <Clock className="h-3 w-3 mr-1" />
                                {item.preparation_time} dakika
                              </div>
                            )}
                            
                            <div className="flex items-center space-x-2">
                              <button 
                                onClick={() => api.trackMenuView(restaurantId!, item.id)}
                                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                <Heart className="h-4 w-4" />
                              </button>
                              <button className="p-2 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                                <Share2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <Search className="h-12 w-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Sonuç bulunamadı</h3>
            <p className="text-gray-600">Arama kriterlerinizi değiştirip tekrar deneyin</p>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="bg-white border-t border-gray-200 py-6 mt-12">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-6 mb-4">
            <div className="flex items-center space-x-2 text-orange-600">
              <QrCode className="h-5 w-5" />
              <span className="text-sm font-medium">QR Menü</span>
            </div>
            <div className="flex items-center space-x-2 text-orange-600">
              <Nfc className="h-5 w-5" />
              <span className="text-sm font-medium">NFC Destekli</span>
            </div>
          </div>
          <p className="text-xs text-gray-500">
            Bu menü NFCmenüm platformu ile oluşturulmuştur
          </p>
        </div>
      </div>
    </div>
  );
}

export default MenuView;