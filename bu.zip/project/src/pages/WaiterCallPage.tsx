import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Bell, 
  CreditCard, 
  HelpCircle, 
  MessageSquare,
  CheckCircle,
  ArrowLeft,
  Clock,
  User
} from 'lucide-react';
import { api } from '../lib/api';

function WaiterCallPage() {
  const { restaurantId } = useParams();
  const navigate = useNavigate();
  const [selectedType, setSelectedType] = useState<'service' | 'bill' | 'help' | null>(null);
  const [tableNumber, setTableNumber] = useState(1);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const callTypes = [
    {
      id: 'service' as const,
      title: 'Servis Talebi',
      description: 'Garson çağır, sipariş ver',
      icon: Bell,
      color: 'bg-blue-100 text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      id: 'bill' as const,
      title: 'Hesap İste',
      description: 'Hesabı getirmesini iste',
      icon: CreditCard,
      color: 'bg-green-100 text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      id: 'help' as const,
      title: 'Yardım',
      description: 'Genel yardım ve bilgi',
      icon: HelpCircle,
      color: 'bg-orange-100 text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedType || !restaurantId) return;

    setLoading(true);

    try {
      const callData = {
        restaurant_id: restaurantId,
        table_number: tableNumber,
        request_type: selectedType,
        message: message.trim() || undefined
      };

      const response = await api.callWaiter(callData);
      
      if (response.success) {
        setSuccess(true);
      }
    } catch (error) {
      console.error('Error calling waiter:', error);
      alert('Garson çağrısı gönderilirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Çağrınız İletildi!</h2>
          <p className="text-gray-600 mb-6">
            Garson çağrınız başarıyla iletildi. En kısa sürede size yardımcı olacağız.
          </p>
          <div className="space-y-3">
            <button
              onClick={() => navigate(`/menu/${restaurantId}`)}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-lg hover:shadow-lg transition-all"
            >
              Menüye Dön
            </button>
            <button
              onClick={() => window.location.reload()}
              className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Yeni Çağrı Yap
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate(`/menu/${restaurantId}`)}
              className="flex items-center text-gray-600 hover:text-orange-600"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Menüye Dön
            </button>
            <h1 className="text-xl font-bold text-gray-900">Garson Çağır</h1>
            <div className="w-20"></div>
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="text-center mb-8">
            <div className="bg-orange-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
              <Bell className="h-8 w-8 text-orange-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Garson Çağır</h2>
            <p className="text-gray-600">
              Nasıl yardımcı olmamızı istiyorsunuz?
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Table Number */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <User className="h-4 w-4 inline mr-1" />
                Masa Numarası
              </label>
              <input
                type="number"
                min="1"
                value={tableNumber}
                onChange={(e) => setTableNumber(parseInt(e.target.value))}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                required
              />
            </div>

            {/* Call Type Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-4">
                Talep Türü Seçin
              </label>
              <div className="grid gap-4">
                {callTypes.map((type) => (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setSelectedType(type.id)}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      selectedType === type.id
                        ? 'border-orange-500 bg-orange-50'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center space-x-4">
                      <div className={`p-3 rounded-lg ${type.color}`}>
                        <type.icon className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{type.title}</h3>
                        <p className="text-sm text-gray-600">{type.description}</p>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Message */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <MessageSquare className="h-4 w-4 inline mr-1" />
                Ek Mesaj (Opsiyonel)
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-4 py-3 focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                rows={4}
                placeholder="Özel isteklerinizi buraya yazabilirsiniz..."
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={!selectedType || loading}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-4 rounded-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all font-semibold"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Çağrı Gönderiliyor...
                </div>
              ) : (
                'Garson Çağır'
              )}
            </button>
          </form>

          {/* Info */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start space-x-3">
              <Clock className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900">Yanıt Süresi</h4>
                <p className="text-blue-700 text-sm">
                  Garsonlarımız genellikle 2-5 dakika içinde size ulaşır.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default WaiterCallPage;