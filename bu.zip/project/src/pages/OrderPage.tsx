import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ShoppingCart, 
  Plus, 
  Minus, 
  Trash2, 
  Clock,
  User,
  Phone,
  MessageSquare,
  CheckCircle,
  ArrowLeft
} from 'lucide-react';
import { api } from '../lib/api';

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image_url?: string;
  preparation_time?: number;
}

interface CartItem extends MenuItem {
  quantity: number;
  notes?: string;
}

interface Restaurant {
  id: string;
  name: string;
  description: string;
  phone?: string;
  address?: string;
}

function OrderPage() {
  const { restaurantId } = useParams();
  const navigate = useNavigate();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    phone: '',
    tableNumber: 1
  });
  const [orderNotes, setOrderNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);

  useEffect(() => {
    loadData();
  }, [restaurantId]);

  const loadData = async () => {
    if (!restaurantId) return;

    try {
      const [restaurantRes, menuRes] = await Promise.all([
        api.getRestaurant(restaurantId),
        api.getPublicMenu(restaurantId)
      ]);

      if (restaurantRes.success) {
        setRestaurant(restaurantRes.data);
      }

      if (menuRes.success) {
        setMenuItems(menuRes.data.items || []);
      }
    } catch (error) {
      console.error('Error loading data:', error);
      // Demo data fallback
      setRestaurant({
        id: restaurantId || '1',
        name: 'Lezzet Durağı',
        description: 'Geleneksel Türk mutfağı',
        phone: '+90 212 123 45 67',
        address: 'Beyoğlu, İstanbul'
      });

      setMenuItems([
        {
          id: '1',
          name: 'Mercimek Çorbası',
          description: 'Geleneksel Türk mercimek çorbası',
          price: 25,
          preparation_time: 10
        },
        {
          id: '2',
          name: 'Adana Kebap',
          description: 'Acılı kıyma kebabı, bulgur pilavı ile',
          price: 85,
          preparation_time: 20
        },
        {
          id: '3',
          name: 'Baklava',
          description: 'Antep fıstıklı geleneksel baklava',
          price: 35,
          preparation_time: 5
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const addToCart = (item: MenuItem) => {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    
    if (existingItem) {
      setCart(cart.map(cartItem =>
        cartItem.id === item.id
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      setCart([...cart, { ...item, quantity: 1 }]);
    }
  };

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity === 0) {
      setCart(cart.filter(item => item.id !== itemId));
    } else {
      setCart(cart.map(item =>
        item.id === itemId
          ? { ...item, quantity: newQuantity }
          : item
      ));
    }
  };

  const updateNotes = (itemId: string, notes: string) => {
    setCart(cart.map(item =>
      item.id === itemId
        ? { ...item, notes }
        : item
    ));
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getTotalTime = () => {
    return Math.max(...cart.map(item => item.preparation_time || 0));
  };

  const handleSubmitOrder = async () => {
    if (cart.length === 0) return;
    if (!customerInfo.name.trim()) {
      alert('Lütfen adınızı girin');
      return;
    }

    setSubmitting(true);

    try {
      const orderData = {
        restaurant_id: restaurantId!,
        table_number: customerInfo.tableNumber,
        items: cart.map(item => ({
          menu_item_id: item.id,
          quantity: item.quantity,
          notes: item.notes || ''
        })),
        customer_name: customerInfo.name,
        customer_phone: customerInfo.phone
      };

      const response = await api.createOrder(orderData);
      
      if (response.success) {
        setOrderSuccess(true);
        setCart([]);
        setCustomerInfo({ name: '', phone: '', tableNumber: 1 });
        setOrderNotes('');
      }
    } catch (error) {
      console.error('Error submitting order:', error);
      alert('Sipariş gönderilirken bir hata oluştu');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  if (orderSuccess) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md w-full text-center">
          <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Siparişiniz Alındı!</h2>
          <p className="text-gray-600 mb-6">
            Siparişiniz başarıyla iletildi. Hazırlanma süresi yaklaşık {getTotalTime()} dakikadır.
          </p>
          <div className="space-y-3">
            <button
              onClick={() => navigate(`/menu/${restaurantId}`)}
              className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-lg hover:shadow-lg transition-all"
            >
              Menüye Dön
            </button>
            <button
              onClick={() => window.location.reload()}
              className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Yeni Sipariş Ver
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => navigate(`/menu/${restaurantId}`)}
              className="flex items-center text-gray-600 hover:text-orange-600"
            >
              <ArrowLeft className="h-5 w-5 mr-2" />
              Menüye Dön
            </button>
            <h1 className="text-xl font-bold text-gray-900">Sipariş Ver</h1>
            <div className="flex items-center space-x-2">
              <ShoppingCart className="h-5 w-5 text-orange-600" />
              <span className="bg-orange-600 text-white text-xs rounded-full px-2 py-1">
                {cart.reduce((total, item) => total + item.quantity, 0)}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Menu Items */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Menü</h2>
            
            <div className="space-y-4">
              {menuItems.map((item) => (
                <div key={item.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
                  <div className="flex items-start space-x-4">
                    <div className="w-20 h-20 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                      {item.image_url ? (
                        <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <ShoppingCart className="h-6 w-6 text-gray-400" />
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{item.name}</h3>
                      <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center space-x-4">
                          <span className="text-lg font-bold text-orange-600">₺{item.price}</span>
                          {item.preparation_time && (
                            <span className="text-xs text-gray-500 flex items-center">
                              <Clock className="h-3 w-3 mr-1" />
                              {item.preparation_time} dk
                            </span>
                          )}
                        </div>
                        <button
                          onClick={() => addToCart(item)}
                          className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors"
                        >
                          Ekle
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cart & Order Form */}
          <div className="space-y-6">
            {/* Cart */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Sepetiniz</h3>
              
              {cart.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Sepetiniz boş</p>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div key={item.id} className="border-b border-gray-200 pb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900">{item.name}</h4>
                        <button
                          onClick={() => updateQuantity(item.id, 0)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                      
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="bg-gray-100 p-1 rounded"
                          >
                            <Minus className="h-4 w-4" />
                          </button>
                          <span className="font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="bg-gray-100 p-1 rounded"
                          >
                            <Plus className="h-4 w-4" />
                          </button>
                        </div>
                        <span className="font-semibold">₺{item.price * item.quantity}</span>
                      </div>
                      
                      <input
                        type="text"
                        placeholder="Özel not (opsiyonel)"
                        value={item.notes || ''}
                        onChange={(e) => updateNotes(item.id, e.target.value)}
                        className="w-full text-sm border border-gray-300 rounded px-3 py-2"
                      />
                    </div>
                  ))}
                  
                  <div className="pt-4 border-t border-gray-200">
                    <div className="flex justify-between items-center text-lg font-bold">
                      <span>Toplam:</span>
                      <span className="text-orange-600">₺{getTotalPrice()}</span>
                    </div>
                    {getTotalTime() > 0 && (
                      <p className="text-sm text-gray-500 mt-1">
                        Tahmini hazırlanma süresi: {getTotalTime()} dakika
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Customer Info */}
            {cart.length > 0 && (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Sipariş Bilgileri</h3>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <User className="h-4 w-4 inline mr-1" />
                      Adınız *
                    </label>
                    <input
                      type="text"
                      required
                      value={customerInfo.name}
                      onChange={(e) => setCustomerInfo({...customerInfo, name: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      placeholder="Adınızı girin"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <Phone className="h-4 w-4 inline mr-1" />
                      Telefon
                    </label>
                    <input
                      type="tel"
                      value={customerInfo.phone}
                      onChange={(e) => setCustomerInfo({...customerInfo, phone: e.target.value})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      placeholder="Telefon numaranız (opsiyonel)"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Masa Numarası
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={customerInfo.tableNumber}
                      onChange={(e) => setCustomerInfo({...customerInfo, tableNumber: parseInt(e.target.value)})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      <MessageSquare className="h-4 w-4 inline mr-1" />
                      Sipariş Notu
                    </label>
                    <textarea
                      value={orderNotes}
                      onChange={(e) => setOrderNotes(e.target.value)}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                      rows={3}
                      placeholder="Özel istekleriniz (opsiyonel)"
                    />
                  </div>
                  
                  <button
                    onClick={handleSubmitOrder}
                    disabled={submitting || !customerInfo.name.trim()}
                    className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-lg hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all font-semibold"
                  >
                    {submitting ? 'Sipariş Gönderiliyor...' : `Sipariş Ver (₺${getTotalPrice()})`}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default OrderPage;