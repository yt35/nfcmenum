import React, { useState } from 'react';
import { Bell, Clock, CheckCircle, Users, ArrowLeft } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

function WaiterPanel() {
  const { user } = useAuth();
  const [orders] = useState([
    {
      id: '1',
      table: 5,
      items: ['Adana Kebap x2', 'Ayran x2'],
      status: 'pending',
      total: 207,
      time: '5 dk önce'
    },
    {
      id: '2', 
      table: 3,
      items: ['Künefe x1', 'Kahve x2'],
      status: 'ready',
      total: 85,
      time: '12 dk önce'
    }
  ]);

  const updateOrderStatus = (orderId: string, status: string) => {
    console.log(`Sipariş ${orderId} durumu: ${status}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Garson Paneli</h1>
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Bell className="h-6 w-6 text-orange-600 mr-2" />
                <div>
                  <p className="text-sm text-gray-600">Bekleyen</p>
                  <p className="text-xl font-bold">3</p>
                </div>
              </div>
            </div>
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center">
                <Clock className="h-6 w-6 text-blue-600 mr-2" />
                <div>
                  <p className="text-sm text-gray-600">Hazırlanıyor</p>
                  <p className="text-xl font-bold">2</p>
                </div>
              </div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center">
                <CheckCircle className="h-6 w-6 text-green-600 mr-2" />
                <div>
                  <p className="text-sm text-gray-600">Hazır</p>
                  <p className="text-xl font-bold">1</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order.id} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="bg-orange-100 p-2 rounded-lg">
                    <Users className="h-5 w-5 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Masa {order.table}</h3>
                    <p className="text-sm text-gray-600">{order.time}</p>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  order.status === 'pending' ? 'bg-orange-100 text-orange-800' :
                  order.status === 'ready' ? 'bg-green-100 text-green-800' :
                  'bg-blue-100 text-blue-800'
                }`}>
                  {order.status === 'pending' ? 'Bekliyor' :
                   order.status === 'ready' ? 'Hazır' : 'Hazırlanıyor'}
                </span>
              </div>
              
              <div className="mb-4">
                <ul className="space-y-1">
                  {order.items.map((item, index) => (
                    <li key={index} className="text-gray-700">{item}</li>
                  ))}
                </ul>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="font-bold text-lg">₺{order.total}</span>
                <div className="space-x-2">
                  {order.status === 'pending' && (
                    <button
                      onClick={() => updateOrderStatus(order.id, 'confirmed')}
                      className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700"
                    >
                      Onayla
                    </button>
                  )}
                  {order.status === 'ready' && (
                    <button
                      onClick={() => updateOrderStatus(order.id, 'served')}
                      className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                    >
                      Servis Edildi
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default WaiterPanel;