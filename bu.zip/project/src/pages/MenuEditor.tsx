import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { 
  ArrowLeft, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  QrCode, 
  Download, 
  Eye,
  Upload,
  X,
  DollarSign,
  Clock,
  Star,
  Image as ImageIcon
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url?: string;
  available: boolean;
  featured: boolean;
  preparation_time?: number;
}

interface MenuCategory {
  id: string;
  name: string;
  description?: string;
  order: number;
}

interface Restaurant {
  id: string;
  name: string;
  description: string;
  logo_url?: string;
  qr_code_url?: string;
  nfc_enabled: boolean;
  theme_color: string;
  created_at: string;
}

function MenuEditor() {
  const { restaurantId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [categories, setCategories] = useState<MenuCategory[]>([]);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [editingCategory, setEditingCategory] = useState<MenuCategory | null>(null);
  const [showQRModal, setShowQRModal] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState('');
  const [loading, setLoading] = useState(true);

  // Demo data
  useEffect(() => {
    // Simulate loading restaurant data
    setTimeout(() => {
      setRestaurant({
        id: restaurantId || '1',
        name: 'Lezzet Durağı',
        description: 'Geleneksel Türk mutfağı',
        theme_color: '#ea580c',
        nfc_enabled: true,
        created_at: new Date().toISOString()
      });

      setCategories([
        { id: '1', name: 'Başlangıçlar', description: 'Lezzetli başlangıç yemekleri', order: 1 },
        { id: '2', name: 'Ana Yemekler', description: 'Doyurucu ana yemekler', order: 2 },
        { id: '3', name: 'Tatlılar', description: 'Tatlı son', order: 3 },
        { id: '4', name: 'İçecekler', description: 'Serinletici içecekler', order: 4 }
      ]);

      setMenuItems([
        {
          id: '1',
          name: 'Mercimek Çorbası',
          description: 'Geleneksel Türk mercimek çorbası, taze nane ile',
          price: 25,
          category: 'Başlangıçlar',
          available: true,
          featured: true,
          preparation_time: 10,
          image_url: 'https://images.pexels.com/photos/539451/pexels-photo-539451.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '2',
          name: 'Adana Kebap',
          description: 'Acılı kıyma kebabı, bulgur pilavı ve salata ile',
          price: 85,
          category: 'Ana Yemekler',
          available: true,
          featured: true,
          preparation_time: 20,
          image_url: 'https://images.pexels.com/photos/4518843/pexels-photo-4518843.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '3',
          name: 'Baklava',
          description: 'Antep fıstıklı geleneksel baklava',
          price: 35,
          category: 'Tatlılar',
          available: true,
          featured: false,
          preparation_time: 5,
          image_url: 'https://images.pexels.com/photos/8477552/pexels-photo-8477552.jpeg?auto=compress&cs=tinysrgb&w=400'
        },
        {
          id: '4',
          name: 'Türk Kahvesi',
          description: 'Geleneksel Türk kahvesi, lokum ile',
          price: 20,
          category: 'İçecekler',
          available: true,
          featured: false,
          preparation_time: 8,
          image_url: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400'
        }
      ]);

      setLoading(false);
    }, 1000);
  }, [restaurantId]);

  const generateQRCode = () => {
    const menuUrl = `${window.location.origin}/menu/${restaurantId}`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(menuUrl)}&bgcolor=ffffff&color=ea580c`;
    setQrCodeUrl(qrUrl);
    setShowQRModal(true);
  };

  const downloadQRCode = () => {
    const link = document.createElement('a');
    link.href = qrCodeUrl;
    link.download = `${restaurant?.name}-qr-kod.png`;
    link.click();
  };

  const handleSaveItem = (item: MenuItem) => {
    if (item.id && menuItems.find(i => i.id === item.id)) {
      setMenuItems(menuItems.map(i => i.id === item.id ? item : i));
    } else {
      const newItem = { ...item, id: Date.now().toString() };
      setMenuItems([...menuItems, newItem]);
    }
    setEditingItem(null);
  };

  const handleDeleteItem = (itemId: string) => {
    if (confirm('Bu ürünü silmek istediğinizden emin misiniz?')) {
      setMenuItems(menuItems.filter(i => i.id !== itemId));
    }
  };

  const handleSaveCategory = (category: MenuCategory) => {
    if (category.id && categories.find(c => c.id === category.id)) {
      setCategories(categories.map(c => c.id === category.id ? category : c));
    } else {
      const newCategory = { ...category, id: Date.now().toString() };
      setCategories([...categories, newCategory]);
    }
    setEditingCategory(null);
  };

  const handleDeleteCategory = (categoryId: string) => {
    const hasItems = menuItems.some(item => item.category === categories.find(c => c.id === categoryId)?.name);
    if (hasItems) {
      alert('Bu kategoride ürünler var. Önce ürünleri silin veya başka kategoriye taşıyın.');
      return;
    }
    if (confirm('Bu kategoriyi silmek istediğinizden emin misiniz?')) {
      setCategories(categories.filter(c => c.id !== categoryId));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/dashboard')}
                className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">{restaurant?.name} - Menü Editörü</h1>
                <p className="text-sm text-gray-600">{restaurant?.description}</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <button
                onClick={() => window.open(`/menu/${restaurantId}`, '_blank')}
                className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 inline-flex items-center transition-colors"
              >
                <Eye className="h-4 w-4 mr-2" />
                Önizleme
              </button>
              <button
                onClick={generateQRCode}
                className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all transform hover:scale-105 inline-flex items-center"
              >
                <QrCode className="h-4 w-4 mr-2" />
                QR Kod Oluştur
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Categories */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-semibold text-gray-900">Kategoriler</h2>
              <button
                onClick={() => setEditingCategory({
                  id: '',
                  name: '',
                  description: '',
                  order: categories.length + 1
                })}
                className="bg-orange-600 text-white p-2 rounded-lg hover:bg-orange-700 transition-colors"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>
            
            <div className="space-y-3">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div>
                    <h3 className="font-medium text-gray-900">{category.name}</h3>
                    <p className="text-sm text-gray-600">{category.description}</p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => setEditingCategory(category)}
                      className="p-1 text-gray-400 hover:text-orange-600 transition-colors"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteCategory(category.id)}
                      className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Menu Items */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-gray-900">Menü Ürünleri</h2>
              <button
                onClick={() => setEditingItem({
                  id: '',
                  name: '',
                  description: '',
                  price: 0,
                  category: categories[0]?.name || '',
                  available: true,
                  featured: false
                })}
                className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all transform hover:scale-105 inline-flex items-center"
              >
                <Plus className="h-4 w-4 mr-2" />
                Yeni Ürün
              </button>
            </div>

            {categories.map((category) => {
              const categoryItems = menuItems.filter(item => item.category === category.name);
              if (categoryItems.length === 0) return null;

              return (
                <div key={category.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">{category.name}</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {categoryItems.map((item) => (
                      <div key={item.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start space-x-4">
                          <div className="w-16 h-16 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                            {item.image_url ? (
                              <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center">
                                <ImageIcon className="h-6 w-6 text-gray-400" />
                              </div>
                            )}
                          </div>
                          
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between">
                              <div>
                                <h4 className="font-medium text-gray-900 flex items-center">
                                  {item.name}
                                  {item.featured && <Star className="h-4 w-4 text-yellow-500 ml-1" />}
                                </h4>
                                <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                                <div className="flex items-center space-x-4 mt-2">
                                  <span className="text-lg font-bold text-orange-600">₺{item.price}</span>
                                  {item.preparation_time && (
                                    <span className="text-xs text-gray-500 flex items-center">
                                      <Clock className="h-3 w-3 mr-1" />
                                      {item.preparation_time} dk
                                    </span>
                                  )}
                                  <span className={`text-xs px-2 py-1 rounded-full ${
                                    item.available 
                                      ? 'bg-green-100 text-green-800' 
                                      : 'bg-red-100 text-red-800'
                                  }`}>
                                    {item.available ? 'Mevcut' : 'Tükendi'}
                                  </span>
                                </div>
                              </div>
                              
                              <div className="flex space-x-2">
                                <button
                                  onClick={() => setEditingItem(item)}
                                  className="p-1 text-gray-400 hover:text-orange-600 transition-colors"
                                >
                                  <Edit className="h-4 w-4" />
                                </button>
                                <button
                                  onClick={() => handleDeleteItem(item.id)}
                                  className="p-1 text-gray-400 hover:text-red-600 transition-colors"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Edit Item Modal */}
      {editingItem && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900">
                {editingItem.id ? 'Ürünü Düzenle' : 'Yeni Ürün'}
              </h3>
              <button
                onClick={() => setEditingItem(null)}
                className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ürün Adı</label>
                <input
                  type="text"
                  value={editingItem.name}
                  onChange={(e) => setEditingItem({ ...editingItem, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Ürün adı"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                <textarea
                  value={editingItem.description}
                  onChange={(e) => setEditingItem({ ...editingItem, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  rows={3}
                  placeholder="Ürün açıklaması"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Fiyat (₺)</label>
                  <input
                    type="number"
                    value={editingItem.price}
                    onChange={(e) => setEditingItem({ ...editingItem, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="0"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Hazırlık Süresi (dk)</label>
                  <input
                    type="number"
                    value={editingItem.preparation_time || ''}
                    onChange={(e) => setEditingItem({ ...editingItem, preparation_time: Number(e.target.value) })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                    placeholder="15"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Kategori</label>
                <select
                  value={editingItem.category}
                  onChange={(e) => setEditingItem({ ...editingItem, category: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                >
                  {categories.map((category) => (
                    <option key={category.id} value={category.name}>{category.name}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Resim URL</label>
                <input
                  type="url"
                  value={editingItem.image_url || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, image_url: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="https://example.com/image.jpg"
                />
              </div>
              
              <div className="flex items-center space-x-6">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={editingItem.available}
                    onChange={(e) => setEditingItem({ ...editingItem, available: e.target.checked })}
                    className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Mevcut</span>
                </label>
                
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    checked={editingItem.featured}
                    onChange={(e) => setEditingItem({ ...editingItem, featured: e.target.checked })}
                    className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Öne Çıkan</span>
                </label>
              </div>
              
              <div className="flex space-x-4 pt-4">
                <button
                  onClick={() => setEditingItem(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  İptal
                </button>
                <button
                  onClick={() => handleSaveItem(editingItem)}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 inline-flex items-center justify-center transition-colors"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Category Modal */}
      {editingCategory && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900">
                {editingCategory.id ? 'Kategoriyi Düzenle' : 'Yeni Kategori'}
              </h3>
              <button
                onClick={() => setEditingCategory(null)}
                className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Kategori Adı</label>
                <input
                  type="text"
                  value={editingCategory.name}
                  onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Kategori adı"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                <textarea
                  value={editingCategory.description || ''}
                  onChange={(e) => setEditingCategory({ ...editingCategory, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  rows={3}
                  placeholder="Kategori açıklaması"
                />
              </div>
              
              <div className="flex space-x-4 pt-4">
                <button
                  onClick={() => setEditingCategory(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  İptal
                </button>
                <button
                  onClick={() => handleSaveCategory(editingCategory)}
                  className="flex-1 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 inline-flex items-center justify-center transition-colors"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* QR Code Modal */}
      {showQRModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900">QR Kod</h3>
              <button
                onClick={() => setShowQRModal(false)}
                className="text-gray-400 hover:text-gray-600 p-1 hover:bg-gray-100 rounded transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <div className="mb-6">
              <div className="bg-white p-4 rounded-xl border-2 border-gray-200 inline-block">
                <img src={qrCodeUrl} alt="QR Kod" className="w-64 h-64" />
              </div>
              <p className="text-sm text-gray-600 mt-4">
                Müşterileriniz bu QR kodu tarayarak menünüze erişebilir
              </p>
            </div>
            
            <div className="space-y-3">
              <button
                onClick={downloadQRCode}
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-3 rounded-lg hover:shadow-lg transition-all transform hover:scale-105 inline-flex items-center justify-center"
              >
                <Download className="h-4 w-4 mr-2" />
                QR Kodu İndir
              </button>
              <button
                onClick={() => setShowQRModal(false)}
                className="w-full border border-gray-300 text-gray-700 py-3 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default MenuEditor;