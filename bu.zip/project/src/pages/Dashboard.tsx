import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Nfc, 
  QrCode, 
  Plus, 
  Settings, 
  BarChart3, 
  Users, 
  Store,
  LogOut,
  Menu as MenuIcon,
  X,
  Eye,
  Edit,
  Trash2,
  Shield,
  ExternalLink,
  UserCheck
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Restaurant {
  id: string;
  name: string;
  description: string;
  logo_url?: string;
  qr_code_url?: string;
  nfc_enabled: boolean;
  created_at: string;
}

function Dashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newRestaurant, setNewRestaurant] = useState({
    name: '',
    description: ''
  });

  const [restaurants, setRestaurants] = useState<Restaurant[]>([
    {
      id: '1',
      name: 'Lezzet Durağı',
      description: 'Geleneksel Türk mutfağı',
      nfc_enabled: true,
      created_at: new Date().toISOString()
    },
    {
      id: '2',
      name: 'Cafe Bohem',
      description: 'Modern cafe deneyimi',
      nfc_enabled: false,
      created_at: new Date().toISOString()
    }
  ]);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
  }, [user, navigate]);

  const handleCreateRestaurant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    try {
      const newRest = {
        id: Date.now().toString(),
        name: newRestaurant.name,
        description: newRestaurant.description,
        nfc_enabled: false,
        created_at: new Date().toISOString()
      };

      setRestaurants([newRest, ...restaurants]);
      setShowCreateModal(false);
      setNewRestaurant({ name: '', description: '' });
    } catch (error) {
      console.error('Error creating restaurant:', error);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleDeleteRestaurant = (restaurantId: string) => {
    if (confirm('Bu restoranı silmek istediğinizden emin misiniz?')) {
      setRestaurants(restaurants.filter(r => r.id !== restaurantId));
    }
  };

  const isAdmin = user?.email === 'admin@nfcmenum.com' || 
                  user?.email === 'nfcmenum@gmail.com' || 
                  user?.email === 'test@admin.com';

  const sidebarItems = [
    { icon: Store, label: 'Restoranlarım', active: true },
    { icon: BarChart3, label: 'Analytics' },
    { icon: QrCode, label: 'QR Kodlar' },
    { icon: Nfc, label: 'NFC Yönetimi' },
    { icon: Users, label: 'Müşteriler' },
    { icon: Settings, label: 'Ayarlar' }
  ];

  if (isAdmin) {
    sidebarItems.push({ icon: Shield, label: 'Admin Panel', active: false });
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0`}>
        <div className="flex items-center justify-between h-16 px-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-br from-orange-600 via-red-600 to-red-700 p-2 rounded-lg">
              <Nfc className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">NFCmenüm</span>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden"
          >
            <X className="h-6 w-6 text-gray-400" />
          </button>
        </div>

        <nav className="mt-6">
          {sidebarItems.map((item, index) => (
            <button
              key={index}
              onClick={() => {
                if (item.label === 'Admin Panel') {
                  navigate('/admin');
                }
              }}
              className={`flex items-center w-full px-6 py-3 text-sm font-medium transition-colors text-left ${
                item.active
                  ? 'text-orange-600 bg-orange-50 border-r-2 border-orange-600'
                  : 'text-gray-700 hover:text-orange-600 hover:bg-gray-50'
              }`}
            >
              <item.icon className="h-5 w-5 mr-3" />
              {item.label}
            </button>
          ))}
        </nav>

        <div className="absolute bottom-0 w-full p-6 border-t border-gray-200">
          <button
            onClick={handleSignOut}
            className="flex items-center w-full px-4 py-2 text-sm font-medium text-gray-700 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          >
            <LogOut className="h-5 w-5 mr-3" />
            Çıkış Yap
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between h-16 px-6">
            <div className="flex items-center">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden mr-4"
              >
                <MenuIcon className="h-6 w-6 text-gray-400" />
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {isAdmin && (
                <button
                  onClick={() => navigate('/admin')}
                  className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 inline-flex items-center text-sm"
                >
                  <Shield className="h-4 w-4 mr-2" />
                  Admin Panel
                </button>
              )}
              <div className="text-sm text-gray-600">
                Hoş geldin, <span className="font-medium">{user?.email}</span>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center">
                  <div className="bg-orange-100 p-3 rounded-lg">
                    <Store className="h-6 w-6 text-orange-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Restoranlar</p>
                    <p className="text-2xl font-bold text-gray-900">{restaurants.length}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center">
                  <div className="bg-green-100 p-3 rounded-lg">
                    <QrCode className="h-6 w-6 text-green-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">QR Tarama</p>
                    <p className="text-2xl font-bold text-gray-900">1,234</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center">
                  <div className="bg-red-100 p-3 rounded-lg">
                    <Nfc className="h-6 w-6 text-red-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">NFC Dokunuş</p>
                    <p className="text-2xl font-bold text-gray-900">567</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <div className="flex items-center">
                  <div className="bg-yellow-100 p-3 rounded-lg">
                    <Users className="h-6 w-6 text-yellow-600" />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Toplam Görüntüleme</p>
                    <p className="text-2xl font-bold text-gray-900">1,801</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Restaurants */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold text-gray-900">Restoranlarım</h2>
                  <button
                    onClick={() => setShowCreateModal(true)}
                    className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-4 py-2 rounded-lg hover:shadow-lg transition-all transform hover:scale-105 inline-flex items-center"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Yeni Restoran
                  </button>
                </div>
              </div>

              <div className="p-6">
                {restaurants.length === 0 ? (
                  <div className="text-center py-12">
                    <Store className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Henüz restoran eklenmemiş</h3>
                    <p className="text-gray-600 mb-4">İlk restoranınızı ekleyerek başlayın</p>
                    <button
                      onClick={() => setShowCreateModal(true)}
                      className="bg-gradient-to-r from-orange-600 to-red-600 text-white px-6 py-3 rounded-lg hover:shadow-lg transition-all transform hover:scale-105"
                    >
                      Restoran Ekle
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {restaurants.map((restaurant) => (
                      <div key={restaurant.id} className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-all">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold text-gray-900">{restaurant.name}</h3>
                          <div className="flex space-x-2">
                            <button 
                              onClick={() => window.open(`/menu/${restaurant.id}`, '_blank')}
                              className="p-2 text-gray-400 hover:text-blue-600 transition-colors"
                              title="Menüyü Görüntüle"
                            >
                              <ExternalLink className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => navigate(`/menu/${restaurant.id}/edit`)}
                              className="p-2 text-gray-400 hover:text-orange-600 transition-colors"
                              title="Menüyü Düzenle"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => navigate(`/waiter/${restaurant.id}`)}
                              className="p-2 text-gray-400 hover:text-green-600 transition-colors"
                              title="Garson Paneli"
                            >
                              <UserCheck className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteRestaurant(restaurant.id)}
                              className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                              title="Restoranı Sil"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                        
                        <p className="text-gray-600 mb-4">{restaurant.description}</p>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex space-x-2">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              <QrCode className="h-3 w-3 mr-1" />
                              QR Aktif
                            </span>
                            {restaurant.nfc_enabled && (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                                <Nfc className="h-3 w-3 mr-1" />
                                NFC Aktif
                              </span>
                            )}
                          </div>
                          <button 
                            onClick={() => navigate(`/menu/${restaurant.id}/edit`)}
                            className="text-orange-600 hover:text-orange-800 font-medium text-sm"
                          >
                            Yönet →
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>

      {/* Create Restaurant Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-md w-full">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Yeni Restoran Ekle</h3>
            
            <form onSubmit={handleCreateRestaurant} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Restoran Adı
                </label>
                <input
                  type="text"
                  required
                  value={newRestaurant.name}
                  onChange={(e) => setNewRestaurant({ ...newRestaurant, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  placeholder="Restoran adını girin"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Açıklama
                </label>
                <textarea
                  value={newRestaurant.description}
                  onChange={(e) => setNewRestaurant({ ...newRestaurant, description: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500"
                  rows={3}
                  placeholder="Restoran hakkında kısa açıklama"
                />
              </div>
              
              <div className="flex space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  İptal
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-orange-600 to-red-600 text-white rounded-lg hover:shadow-lg transition-all transform hover:scale-105"
                >
                  Oluştur
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default Dashboard;