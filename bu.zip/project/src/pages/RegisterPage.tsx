import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Nfc, Eye, EyeOff, ArrowLeft, CheckCircle, AlertCircle, Wifi, WifiOff } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

function RegisterPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    businessName: '',
    phone: '',
    plan: 'free'
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [networkStatus, setNetworkStatus] = useState(navigator.onLine);
  
  const { signUp } = useAuth();
  const navigate = useNavigate();

  // Network durumu takibi
  React.useEffect(() => {
    const handleOnline = () => {
      setNetworkStatus(true);
      console.log('🌐 Network: Online');
    };
    
    const handleOffline = () => {
      setNetworkStatus(false);
      console.log('🌐 Network: Offline');
      setError('İnternet bağlantınız kesildi. Lütfen bağlantınızı kontrol edin.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Network kontrolü
    if (!networkStatus) {
      setError('İnternet bağlantınızı kontrol edin');
      setLoading(false);
      return;
    }

    // Validation
    if (formData.password !== formData.confirmPassword) {
      setError('Şifreler eşleşmiyor');
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('Şifre en az 6 karakter olmalıdır');
      setLoading(false);
      return;
    }

    if (!formData.firstName.trim() || !formData.lastName.trim() || !formData.businessName.trim()) {
      setError('Tüm zorunlu alanları doldurun');
      setLoading(false);
      return;
    }

    try {
      console.log('🔄 Attempting to register user:', formData.email);
      
      const { data, error } = await signUp(formData.email, formData.password, {
        firstName: formData.firstName.trim(),
        lastName: formData.lastName.trim(),
        businessName: formData.businessName.trim(),
        phone: formData.phone.trim(),
        plan: formData.plan
      });

      console.log('📤 Registration result:', { data, error });

      if (error) {
        console.error('❌ Registration error:', error);
        
        // Supabase hata mesajlarını Türkçe'ye çevir
        let errorMessage = 'Kayıt sırasında bir hata oluştu';
        
        if (error.message?.includes('already registered') || error.message?.includes('already exists')) {
          errorMessage = 'Bu e-posta adresi zaten kayıtlı';
        } else if (error.message?.includes('invalid email')) {
          errorMessage = 'Geçersiz e-posta adresi';
        } else if (error.message?.includes('password')) {
          errorMessage = 'Şifre gereksinimlerini karşılamıyor';
        } else if (error.message?.includes('network') || error.message?.includes('Failed to fetch') || error.message?.includes('bağlantı')) {
          errorMessage = 'Bağlantı hatası. İnternet bağlantınızı kontrol edin ve tekrar deneyin.';
        } else if (error.message) {
          errorMessage = error.message;
        }
        
        setError(errorMessage);
      } else if (data?.user) {
        console.log('✅ Registration successful for user:', data.user.id);
        setSuccess(true);
        
        // Başarılı kayıt sonrası yönlendirme
        setTimeout(() => {
          if (data.user.email_confirmed_at) {
            // E-posta onaylanmışsa direkt dashboard'a git
            navigate('/dashboard');
          } else {
            // E-posta onayı gerekiyorsa bilgi ver
            navigate('/login', { 
              state: { 
                message: 'Kayıt başarılı! Giriş yapabilirsiniz.' 
              } 
            });
          }
        }, 2000);
      } else {
        setError('Kayıt tamamlanamadı. Lütfen tekrar deneyin.');
      }
    } catch (err: any) {
      console.error('❌ Registration exception:', err);
      
      if (err.name === 'TypeError' && err.message.includes('fetch')) {
        setError('Bağlantı hatası. İnternet bağlantınızı kontrol edin ve tekrar deneyin.');
      } else {
        setError('Beklenmeyen bir hata oluştu. Lütfen tekrar deneyin.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full text-center">
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
            <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Kayıt Başarılı!</h2>
            <p className="text-gray-600 mb-6">
              Hesabınız başarıyla oluşturuldu. Dashboard'a yönlendiriliyorsunuz...
            </p>
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600 mx-auto"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div>
          <Link to="/" className="flex items-center justify-center space-x-3 mb-8">
            <div className="bg-gradient-to-br from-orange-600 via-red-600 to-red-700 p-2.5 rounded-xl shadow-lg">
              <Nfc className="h-7 w-7 text-white" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              NFCmenüm
            </span>
          </Link>
          
          <h2 className="text-center text-3xl font-bold text-gray-900">
            Hesap Oluştur
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Zaten hesabınız var mı?{' '}
            <Link to="/login" className="font-medium text-orange-600 hover:text-orange-500">
              Giriş yapın
            </Link>
          </p>
        </div>

        {/* Network Status Indicator */}
        {!networkStatus && (
          <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm flex items-center">
            <WifiOff className="h-4 w-4 mr-2 flex-shrink-0" />
            İnternet bağlantısı yok. Lütfen bağlantınızı kontrol edin.
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-xl p-8 border border-gray-100">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm flex items-center">
                <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
                {error}
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">
                  Ad *
                </label>
                <input
                  id="firstName"
                  name="firstName"
                  type="text"
                  required
                  value={formData.firstName}
                  onChange={handleChange}
                  className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500 focus:z-10 sm:text-sm"
                  placeholder="Adınız"
                />
              </div>
              <div>
                <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">
                  Soyad *
                </label>
                <input
                  id="lastName"
                  name="lastName"
                  type="text"
                  required
                  value={formData.lastName}
                  onChange={handleChange}
                  className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500 focus:z-10 sm:text-sm"
                  placeholder="Soyadınız"
                />
              </div>
            </div>

            <div>
              <label htmlFor="businessName" className="block text-sm font-medium text-gray-700 mb-1">
                İşletme Adı *
              </label>
              <input
                id="businessName"
                name="businessName"
                type="text"
                required
                value={formData.businessName}
                onChange={handleChange}
                className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500 focus:z-10 sm:text-sm"
                placeholder="Restoran/Cafe adınız"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                E-posta *
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                value={formData.email}
                onChange={handleChange}
                className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500 focus:z-10 sm:text-sm"
                placeholder="E-posta adresiniz"
              />
            </div>

            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">
                Telefon
              </label>
              <input
                id="phone"
                name="phone"
                type="tel"
                value={formData.phone}
                onChange={handleChange}
                className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500 focus:z-10 sm:text-sm"
                placeholder="Telefon numaranız (opsiyonel)"
              />
            </div>

            <div className="relative">
              <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                Şifre *
              </label>
              <input
                id="password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                required
                value={formData.password}
                onChange={handleChange}
                className="appearance-none relative block w-full px-3 py-3 pr-10 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500 focus:z-10 sm:text-sm"
                placeholder="En az 6 karakter"
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 top-6 pr-3 flex items-center"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="h-5 w-5 text-gray-400" />
                ) : (
                  <Eye className="h-5 w-5 text-gray-400" />
                )}
              </button>
            </div>

            <div className="relative">
              <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                Şifre Tekrar *
              </label>
              <input
                id="confirmPassword"
                name="confirmPassword"
                type={showConfirmPassword ? 'text' : 'password'}
                required
                value={formData.confirmPassword}
                onChange={handleChange}
                className="appearance-none relative block w-full px-3 py-3 pr-10 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-lg focus:outline-none focus:ring-orange-500 focus:border-orange-500 focus:z-10 sm:text-sm"
                placeholder="Şifrenizi tekrar girin"
              />
              <button
                type="button"
                className="absolute inset-y-0 right-0 top-6 pr-3 flex items-center"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              >
                {showConfirmPassword ? (
                  <EyeOff className="h-5 w-5 text-gray-400" />
                ) : (
                  <Eye className="h-5 w-5 text-gray-400" />
                )}
              </button>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Şifre Gereksinimleri:</h4>
              <ul className="text-xs text-gray-600 space-y-1">
                <li className={`flex items-center ${formData.password.length >= 6 ? 'text-green-600' : ''}`}>
                  <CheckCircle className={`h-3 w-3 mr-2 ${formData.password.length >= 6 ? 'text-green-600' : 'text-gray-400'}`} />
                  En az 6 karakter
                </li>
                <li className={`flex items-center ${formData.password === formData.confirmPassword && formData.password ? 'text-green-600' : ''}`}>
                  <CheckCircle className={`h-3 w-3 mr-2 ${formData.password === formData.confirmPassword && formData.password ? 'text-green-600' : 'text-gray-400'}`} />
                  Şifreler eşleşmeli
                </li>
              </ul>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading || !networkStatus}
                className="group relative w-full flex justify-center py-3 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-gradient-to-r from-orange-600 to-red-600 hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Hesap oluşturuluyor...
                  </div>
                ) : !networkStatus ? (
                  <div className="flex items-center">
                    <WifiOff className="h-4 w-4 mr-2" />
                    Bağlantı Bekleniyor
                  </div>
                ) : (
                  <div className="flex items-center">
                    <Wifi className="h-4 w-4 mr-2" />
                    Hesap Oluştur
                  </div>
                )}
              </button>
            </div>

            <div className="text-xs text-gray-500 text-center">
              Hesap oluşturarak{' '}
              <a href="#" className="text-orange-600 hover:text-orange-500">Kullanım Şartları</a>
              {' '}ve{' '}
              <a href="#" className="text-orange-600 hover:text-orange-500">Gizlilik Politikası</a>
              'nı kabul etmiş olursunuz.
            </div>
          </form>
        </div>

        <div className="text-center">
          <Link to="/" className="inline-flex items-center text-sm text-gray-600 hover:text-orange-600">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Ana sayfaya dön
          </Link>
        </div>
      </div>
    </div>
  );
}

export default RegisterPage;