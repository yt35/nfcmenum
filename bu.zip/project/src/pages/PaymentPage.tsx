import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { 
  CreditCard, 
  Shield, 
  CheckCircle, 
  ArrowLeft,
  Lock,
  Star,
  Crown
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { api } from '../lib/api';

interface Plan {
  id: string;
  name: string;
  price: number;
  features: string[];
  popular: boolean;
}

function PaymentPage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const planId = searchParams.get('plan');

  const plans: Plan[] = [
    {
      id: 'professional',
      name: 'Profesyonel',
      price: 299,
      features: [
        '3 Restoran',
        'QR + NFC Menü',
        'Sınırsız Ürün',
        'Gelişmiş Analytics',
        'Özel Tasarım',
        'Öncelikli Destek',
        '2 Adet Ücretsiz Stand'
      ],
      popular: true
    },
    {
      id: 'enterprise',
      name: 'Kurumsal',
      price: 799,
      features: [
        'Sınırsız Restoran',
        'Tüm Özellikler',
        'API Erişimi',
        'Özel Entegrasyonlar',
        'Dedicated Hesap Yöneticisi',
        '5 Adet Ücretsiz Stand',
        'Özel Eğitim'
      ],
      popular: false
    }
  ];

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    const plan = plans.find(p => p.id === planId);
    if (plan) {
      setSelectedPlan(plan);
    } else {
      navigate('/');
    }
  }, [user, planId, navigate]);

  const handlePayment = async () => {
    if (!selectedPlan || !user) return;

    setLoading(true);
    setError('');

    try {
      // PayTR ödeme isteği oluştur
      const paymentData = {
        plan_id: selectedPlan.id,
        user_email: user.email || '',
        amount: selectedPlan.price,
        currency: 'TRY'
      };

      const response = await api.createPayment(paymentData);
      
      if (response.success && response.data.payment_url) {
        // PayTR ödeme sayfasına yönlendir
        window.location.href = response.data.payment_url;
      } else {
        throw new Error('Ödeme sayfası oluşturulamadı');
      }
    } catch (err: any) {
      setError(err.message || 'Ödeme işlemi başlatılamadı');
    } finally {
      setLoading(false);
    }
  };

  if (!selectedPlan) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-red-50">
      <div className="max-w-4xl mx-auto px-4 py-12">
        {/* Back Button */}
        <div className="mb-8">
          <button
            onClick={() => navigate('/')}
            className="inline-flex items-center text-gray-600 hover:text-orange-600 transition-colors"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Geri Dön
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Plan Summary */}
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="text-center mb-8">
              <div className="inline-flex items-center space-x-2 bg-orange-100 px-4 py-2 rounded-full mb-4">
                {selectedPlan.id === 'enterprise' ? (
                  <Crown className="h-5 w-5 text-orange-600" />
                ) : (
                  <Star className="h-5 w-5 text-orange-600" />
                )}
                <span className="text-orange-600 font-medium">{selectedPlan.name} Plan</span>
              </div>
              
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                ₺{selectedPlan.price}<span className="text-lg text-gray-600">/ay</span>
              </h2>
              
              {selectedPlan.popular && (
                <span className="inline-block bg-gradient-to-r from-orange-600 to-red-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                  En Popüler
                </span>
              )}
            </div>

            <div className="space-y-4 mb-8">
              <h3 className="font-semibold text-gray-900 mb-4">Plan Özellikleri:</h3>
              {selectedPlan.features.map((feature, index) => (
                <div key={index} className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-900 mb-2">Ödeme Özeti</h4>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">{selectedPlan.name} Plan (Aylık)</span>
                <span className="font-semibold">₺{selectedPlan.price}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-600">KDV (%18)</span>
                <span className="font-semibold">₺{Math.round(selectedPlan.price * 0.18)}</span>
              </div>
              <hr className="my-2" />
              <div className="flex justify-between items-center">
                <span className="font-bold text-gray-900">Toplam</span>
                <span className="font-bold text-xl text-orange-600">
                  ₺{selectedPlan.price + Math.round(selectedPlan.price * 0.18)}
                </span>
              </div>
            </div>
          </div>

          {/* Payment Form */}
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
            <div className="text-center mb-8">
              <div className="bg-green-100 p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Güvenli Ödeme</h3>
              <p className="text-gray-600">
                PayTR güvenli ödeme sistemi ile korumalı ödeme
              </p>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg text-sm mb-6">
                {error}
              </div>
            )}

            <div className="space-y-6 mb-8">
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center space-x-3">
                  <CreditCard className="h-6 w-6 text-blue-600" />
                  <div>
                    <h4 className="font-semibold text-blue-900">Desteklenen Ödeme Yöntemleri</h4>
                    <p className="text-blue-700 text-sm">
                      Kredi Kartı, Banka Kartı, Havale/EFT
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-green-50 p-4 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Lock className="h-6 w-6 text-green-600" />
                  <div>
                    <h4 className="font-semibold text-green-900">256-bit SSL Şifreleme</h4>
                    <p className="text-green-700 text-sm">
                      Ödeme bilgileriniz güvenli şekilde şifrelenir
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <button
                onClick={handlePayment}
                disabled={loading}
                className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white py-4 rounded-lg hover:shadow-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105 font-semibold"
              >
                {loading ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Ödeme Sayfasına Yönlendiriliyor...
                  </div>
                ) : (
                  `₺${selectedPlan.price + Math.round(selectedPlan.price * 0.18)} Öde`
                )}
              </button>

              <p className="text-xs text-gray-500 text-center">
                Ödeme yaparak{' '}
                <a href="#" className="text-orange-600 hover:text-orange-500">Kullanım Şartları</a>
                {' '}ve{' '}
                <a href="#" className="text-orange-600 hover:text-orange-500">Gizlilik Politikası</a>
                'nı kabul etmiş olursunuz.
              </p>
            </div>

            <div className="mt-8 pt-6 border-t border-gray-200">
              <div className="flex items-center justify-center space-x-4 text-sm text-gray-500">
                <span>Powered by</span>
                <div className="bg-blue-600 text-white px-3 py-1 rounded font-bold">
                  PayTR
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PaymentPage;