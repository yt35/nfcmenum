import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import ResetPasswordPage from './pages/ResetPasswordPage';
import Dashboard from './pages/Dashboard';
import AdminPanel from './pages/AdminPanel';
import MenuEditor from './pages/MenuEditor';
import MenuView from './pages/MenuView';
import WaiterPanel from './pages/WaiterPanel';
import ContactPage from './pages/ContactPage';
import PaymentPage from './pages/PaymentPage';
import OrderPage from './pages/OrderPage';
import WaiterCallPage from './pages/WaiterCallPage';
import { AuthProvider } from './contexts/AuthContext';

function App() {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/payment" element={<PaymentPage />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/menu/:restaurantId/edit" element={<MenuEditor />} />
          <Route path="/menu/:restaurantId" element={<MenuView />} />
          <Route path="/menu/:restaurantId/order" element={<OrderPage />} />
          <Route path="/menu/:restaurantId/waiter" element={<WaiterCallPage />} />
          <Route path="/waiter/:restaurantId" element={<WaiterPanel />} />
        </Routes>
      </div>
    </AuthProvider>
  );
}

export default App;